// ━━━ STAR TROOP — GAME ENGINE ━━━
import { CANVAS_WIDTH, CANVAS_HEIGHT, WORLD_WIDTH, GROUND_Y } from './constants';
import { DayNightSystem } from './systems/DayNightSystem';
import { CameraSystem } from './systems/CameraSystem';
import { WaveManager } from './systems/WaveManager';
import { CombatSystem } from './systems/CombatSystem';
import { ResourceSystem } from './systems/ResourceSystem';
import { BuildSystem } from './systems/BuildSystem';
import { AISystem } from './systems/AISystem';
import { FXSystem } from './systems/FXSystem';
import { Player } from './entities/Player';
import { Renderer } from './renderer/Renderer';
import { LifepodSystem } from './systems/LifepodSystem';
import { SquadFormation } from './systems/SquadFormation';
import { SquadIdle } from './systems/SquadIdle';

export class GameEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    this.ctx.imageSmoothingEnabled = false;

    this.running = false;
    this.lastTime = 0;
    this.animFrame = null;
    this.paused = false;
    this.gameOver       = false;
    this.gameOverTimer  = 0;
    this.gameOverReason = '';
    this.gameWon        = false;
    this.gameWonTimer   = 0;

    // Entity pools
    this.entities = {
      player: null,
      bugs: [],
      buildings: [],
      projectiles: [],
      oreNodes: [],
      survivors: [],
      infantry: [],
      particles: [],
      grenades: [],
    };

    // Input state
    this.keys = {};
    this.mouseDown = false;
    this.mouseX = 0;
    this.mouseY = 0;

    // Systems
    this.dayNight = new DayNightSystem();
    this.camera = new CameraSystem();
    this.waveManager = new WaveManager();
    this.combat = new CombatSystem();
    this.resources = new ResourceSystem();
    this.buildSystem = new BuildSystem();
    this.ai = new AISystem();
    this.fx = new FXSystem();
    this.renderer = new Renderer(this.ctx);

    // Squad + rescue systems
    this.lifepods      = new LifepodSystem();
    this.squadFormation = new SquadFormation();
    this.squadIdle     = new SquadIdle();

    // Game state
    this.ore = 20;
    this.wave = 0;
    this.score = 0;
    this.ammo = 999;
    this.gameTime = 0; // ms of actual gameplay (paused time excluded)
    this.buildFailFlash = 0; // ms remaining for HUD build-fail indicator

    this._bindInput();
  }

  init() {
    // Create player at world center
    const centerX = WORLD_WIDTH / 2;
    this.entities.player = new Player(centerX, GROUND_Y);

    // Build initial base
    this.buildSystem.buildInitialBase(this.entities, centerX);

    // Scatter ore nodes
    this.resources.scatterOreNodes(this.entities, centerX);

    // Survivor pods arrive via lifepods — triggered on day start

    // Start day
    this.dayNight.reset();
    this.waveManager.reset();
    this.camera.init(centerX);
    this.gameTime = 0;
  }

  start() {
    this.running = true;
    this.lastTime = performance.now();
    this._loop(this.lastTime);
  }

  stop() {
    this.running = false;
    if (this.animFrame) cancelAnimationFrame(this.animFrame);
  }

  destroy() {
    this.stop();
    this._unbindInput();
  }

  _loop(now) {
    if (!this.running) return;
    const dt = Math.min(now - this.lastTime, 50); // cap delta
    this.lastTime = now;

    this.update(dt);
    this.render();

    this.animFrame = requestAnimationFrame((t) => this._loop(t));
  }

  update(dt) {
    if (this.paused)    return;
    if (this.gameOver) { this.gameOverTimer += dt; return; }
    if (this.gameWon)   { this.gameWonTimer  += dt; return; }

    this.gameTime += dt;
    const player = this.entities.player;

    // Player input
    player.handleInput(this.keys, this.mouseDown, dt, this);

    // Day/night cycle
    const prevPhase = this.dayNight.phase;
    this.dayNight.update(dt);

    // Transition handling
    if (prevPhase === 'night' && this.dayNight.phase === 'dawn') {
      this.waveManager.endWave();
      // Dawn: pull squad back into formation
      this.squadFormation.reformFormation(this.entities.infantry);
      // Ammo resupply at dawn
      this.ammo = Math.min(this.ammo + 60, 999);
    }
    if (prevPhase === 'dusk' && this.dayNight.phase === 'night') {
      this.wave++;
      this.waveManager.startWave(this.wave);
      // Dusk: disperse squad to defensePoints
      this.squadFormation.disperseToDefensePoints(this.entities.infantry, this.entities.buildings);
    }
    if (prevPhase === 'dawn' && this.dayNight.phase === 'day') {
      // New day: trigger potential lifepod arrival
      this.lifepods.onDayStart(this);
    }

    // Wave spawning
    if (this.dayNight.phase === 'night') {
      this.waveManager.update(dt, this.entities, this.camera);
    }

    // Update all entities
    player.update(dt, this);

    // Lifepod descent + landing
    this.lifepods.update(dt, this);

    // Squad formation (slot targeting + drift)
    this.squadFormation.update(player, this.entities.infantry, dt, this.gameTime);

    // Squad idle state machine
    this.squadIdle.update(this.entities.infantry, dt);

    for (let i = this.entities.bugs.length - 1; i >= 0; i--) {
      const bug = this.entities.bugs[i];
      this.ai.updateBug(bug, dt, this);
      bug.update(dt, this);
      if (bug.dead && bug.deathTimer > 1500) {
        this.entities.bugs.splice(i, 1);
      }
    }

    for (let i = this.entities.infantry.length - 1; i >= 0; i--) {
      const mi = this.entities.infantry[i];
      this.ai.updateInfantry(mi, dt, this);
      mi.update(dt, this);
      if (mi.hp <= 0) {
        this.fx.spawnDeathFX(mi.x, mi.y, '#cc4444', this.entities.particles);
        this.entities.infantry.splice(i, 1);
      }
    }

    // Projectiles
    this.combat.updateProjectiles(dt, this);

    // Grenades
    this.combat.updateGrenades(dt, this);

    // Buildings damage check
    for (const b of this.entities.buildings) {
      if (b.hp <= 0 && !b.destroyed) {
        b.destroyed = true;
        this.fx.spawnExplosion(b.x + b.width / 2, b.y + b.height / 2, this.entities.particles);
      }
    }

    // Win/Lose checks
    this._checkEndConditions();

    // Particles
    this.fx.updateParticles(dt, this.entities.particles);

    // Camera
    this.camera.follow(player.x, dt, player.facing, Math.abs(player.vx) > 0.2);

    // Timers
    if (this.buildFailFlash > 0) this.buildFailFlash -= dt;
    // Screen shake decay
    this.fx.updateShake(dt);
  }

  render() {
    this.renderer.render(this);
  }

  // ── Win / Lose ────────────────────────────────────────────────────────────
  triggerGameOver(reason = 'hq_destroyed') {
    if (this.gameOver || this.gameWon) return;
    this.gameOver      = true;
    this.gameOverReason = reason;
    this.gameOverTimer  = 0;
    // Big shake on game over
    this.fx.addShake(20);
  }

  triggerWin() {
    if (this.gameOver || this.gameWon) return;
    this.gameWon      = true;
    this.gameWonTimer  = 0;
  }

  _checkEndConditions() {
    if (this.gameOver || this.gameWon) return;

    // LOSE — HQ destroyed
    const hq = this.entities.buildings.find(b => b.type === 'COMMAND_POST');
    if (hq && hq.destroyed) {
      this.triggerGameOver('hq_destroyed');
      return;
    }

    // LOSE — player dead (handled in Player.takeDamage → engine.triggerGameOver)

    // WIN — survive N nights (wave 5+ clear at dawn/day)
    const WIN_WAVES = 5;
    const afterFight = this.dayNight.phase === 'day' || this.dayNight.phase === 'dawn';
    const bugsCleared = this.entities.bugs.every(b => b.dead);
    if (this.wave >= WIN_WAVES && bugsCleared && !this.waveManager.active && afterFight) {
      this.triggerWin();
    }
  }

  // Get world mouse position
  getWorldMouseX() {
    return this.mouseX + this.camera.x - CANVAS_WIDTH / 2;
  }

  _bindInput() {
    // Only preventDefault for actual game keys — never block browser shortcuts
    const GAME_KEYS = new Set([
      'KeyA','KeyD','KeyW','KeyS','Space',
      'ArrowLeft','ArrowRight','ArrowUp','ArrowDown',
      'KeyG','KeyE','KeyB','Escape',
    ]);

    this._onKeyDown = (e) => {
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      this.keys[e.code] = true;

      // ESC — toggle pause (unless game over / won)
      if (e.code === 'Escape') {
        if (!this.gameOver && !this.gameWon) {
          this.paused = !this.paused;
          // Release all movement keys so player doesn't slide when unpausing
          if (this.paused) this._clearKeys();
        }
      }

      // R — restart when game over or won
      if (e.code === 'KeyR' && (this.gameOver || this.gameWon)) {
        this._requestRestart();
      }
    };

    this._onKeyUp = (e) => {
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      this.keys[e.code] = false;
    };

    // CRITICAL: when window loses focus, clear ALL keys and release mouse
    // This prevents stuck keys when alt-tabbing, clicking outside, etc.
    this._onBlur = () => {
      this._clearKeys();
      this.mouseDown = false;
    };

    this._onMouseDown = (e) => {
      // Left click only — right click does NOTHING (no context menu either)
      if (e.button === 0) {
        this.mouseDown = true;
        // Click on canvas focuses it for keyboard input
        this.canvas.focus();
      }
      // Block context menu for all mouse buttons on canvas
    };

    this._onMouseUp = (e) => {
      if (e.button === 0) this.mouseDown = false;
    };

    this._onContextMenu = (e) => {
      // Completely suppress right-click context menu on canvas
      e.preventDefault();
      e.stopPropagation();
    };

    this._onMouseMove = (e) => {
      const rect   = this.canvas.getBoundingClientRect();
      const scaleX = CANVAS_WIDTH  / rect.width;
      const scaleY = CANVAS_HEIGHT / rect.height;
      this.mouseX  = (e.clientX - rect.left) * scaleX;
      this.mouseY  = (e.clientY - rect.top)  * scaleY;
    };

    // Mouse leaves canvas — release fire so we don't get stuck shooting
    this._onMouseLeave = () => {
      this.mouseDown = false;
    };

    window.addEventListener('keydown',  this._onKeyDown);
    window.addEventListener('keyup',    this._onKeyUp);
    window.addEventListener('blur',     this._onBlur);
    this.canvas.addEventListener('mousedown',    this._onMouseDown);
    this.canvas.addEventListener('mouseup',      this._onMouseUp);
    this.canvas.addEventListener('mousemove',    this._onMouseMove);
    this.canvas.addEventListener('mouseleave',   this._onMouseLeave);
    this.canvas.addEventListener('contextmenu',  this._onContextMenu);
  }

  _unbindInput() {
    window.removeEventListener('keydown',  this._onKeyDown);
    window.removeEventListener('keyup',    this._onKeyUp);
    window.removeEventListener('blur',     this._onBlur);
    this.canvas.removeEventListener('mousedown',   this._onMouseDown);
    this.canvas.removeEventListener('mouseup',     this._onMouseUp);
    this.canvas.removeEventListener('mousemove',   this._onMouseMove);
    this.canvas.removeEventListener('mouseleave',  this._onMouseLeave);
    this.canvas.removeEventListener('contextmenu', this._onContextMenu);
  }

  // Clear all held keys — called on blur and pause
  _clearKeys() {
    this.keys = {};
    if (this.entities.player) {
      this.entities.player.vx = 0;
      this.entities.player.isFiring = false;
      this.entities.player.sustainedFireMs = 0;
    }
    this.mouseDown = false;
  }

  // Signal to React layer to restart — emits a custom event
  _requestRestart() {
    this.canvas.dispatchEvent(new CustomEvent('st:restart', { bubbles: true }));
  }
}