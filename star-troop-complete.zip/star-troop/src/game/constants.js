// ━━━ STAR TROOP — GAME CONSTANTS ━━━
// Single source of truth. All tunable values live here.
// Nothing in game code should hardcode a gameplay number.

// ── Canvas / World ─────────────────────────────────────────────────────────
export const CANVAS_WIDTH  = 960;
export const CANVAS_HEIGHT = 540;
export const WORLD_WIDTH   = 4800;
export const GROUND_Y      = 420;
export const GRAVITY       = 0.6;
export const FRICTION      = 0.85;

// ── Player ─────────────────────────────────────────────────────────────────
export const PLAYER = {
  WIDTH:             28,
  HEIGHT:            40,
  SPEED:             3.2,
  JUMP_FORCE:        -11,
  MAX_HP:            100,
  FIRE_RATE:         120,    // ms between shots
  BULLET_SPEED:      12,
  BULLET_DAMAGE:     18,
  GRENADE_COOLDOWN:  3000,
  GRENADE_DAMAGE:    60,
  GRENADE_RADIUS:    80,
};

// ── Mobile Infantry ────────────────────────────────────────────────────────
export const MI = {
  WIDTH:              24,
  HEIGHT:             38,
  SPEED:              2.0,
  MAX_HP:             60,
  FIRE_RATE:          650,   // ms between shots (slower than player — feels like support)
  BULLET_SPEED:       10,
  BULLET_DAMAGE:      12,
  // Combat
  ENGAGE_RANGE:       260,   // px — will shoot any bug within this distance
  MELEE_THRESHOLD:    80,    // px — inches toward bug if it gets this close
  AT_POST_THRESHOLD:  12,    // px — counts as "arrived at defense point"
  HOLD_SPEED_MULT:    0.7,   // speed multiplier when moving to hold position
  // Follow formation (backup values — SquadFormation owns these)
  HOLD_SCATTER:       60,    // px — legacy scatter range (no longer used, kept for compat)
};

// ── Warrior Bug ────────────────────────────────────────────────────────────
export const WARRIOR_BUG = {
  WIDTH:        36,
  HEIGHT:       28,
  SPEED:        1.4,
  MAX_HP:       55,
  DAMAGE:       12,
  ATTACK_RATE:  800,   // ms between melee attacks
  MELEE_RANGE:  22,    // px — triggers attack
  SCORE:        10,
};

// ── Buildings ──────────────────────────────────────────────────────────────
export const BUILDINGS = {
  COMMAND_POST: { width: 64, height: 56, hp: 300, cost:  0, label: 'HQ'       },
  BARRACKS:     { width: 48, height: 44, hp: 150, cost: 30, label: 'Barracks' },
  WALL:         { width: 20, height: 48, hp: 200, cost: 15, label: 'Wall'     },
  GUARD_TOWER:  { width: 32, height: 56, hp: 120, cost: 40, label: 'Tower'    },
};

// ── Day / Night ────────────────────────────────────────────────────────────
export const DAY_NIGHT = {
  DAY_DURATION:       45000,  // ms
  NIGHT_DURATION:     35000,  // ms
  DAWN_TRANSITION:     3000,  // ms
  DUSK_TRANSITION:     3000,  // ms
};

// ── Wave Spawner ───────────────────────────────────────────────────────────
export const WAVES = {
  BASE_COUNT:      4,
  SCALE_PER_WAVE:  3,
  SPAWN_INTERVAL:  1200,  // ms between individual bug spawns
  SPAWN_MARGIN:    420,   // px off-screen — wide enough to hide pop-in
  MIN_INTERVAL:    400,   // ms floor so waves never instant-spawn
  INTERVAL_DECAY:  60,    // ms reduction per wave number
};

// ── Resources ──────────────────────────────────────────────────────────────
export const ORE_NODE = {
  WIDTH:        20,
  HEIGHT:       16,
  YIELD:        10,
  PICKUP_RANGE: 40,
};

export const SURVIVOR = {
  WIDTH:        24,
  HEIGHT:       36,
  RESCUE_RANGE: 40,
};

// ── Colors ─────────────────────────────────────────────────────────────────
export const COLORS = {
  // Sky
  SKY_DAY:          '#c45a20',
  SKY_SUNSET:       '#6b1a3a',
  SKY_NIGHT:        '#0d0a1a',
  SKY_DAWN:         '#8b3a1a',
  // Terrain
  GROUND:           '#3a2a1a',
  GROUND_DARK:      '#2a1a0e',
  TERRAIN_ACCENT:   '#4a3520',
  // Entities
  PLAYER:           '#5a7a4a',
  PLAYER_SKIN:      '#d4a574',
  MI_UNIFORM:       '#4a6a3a',
  BUG_BODY:         '#2a1a0a',
  BUG_ACCENT:       '#4a2a10',
  BUG_BLOOD:        '#1a8a2a',
  // FX
  MUZZLE_FLASH:     '#ffaa22',
  BULLET:           '#ffdd44',
  EXPLOSION:        '#ff6622',
  GRENADE:          '#886644',
  // Resources
  ORE:              '#88ccff',
  ORE_GLOW:         '#4488cc',
  // Buildings
  BUILDING:         '#6a6a5a',
  BUILDING_ACCENT:  '#8a8a7a',
  WALL:             '#7a7a6a',
  HQ:               '#5a6a5a',
  SURVIVOR_POD:     '#44aaff',
  // Health
  HEALTH_GREEN:     '#44cc44',
  HEALTH_RED:       '#cc4444',
  // UI
  UI_BG:            'rgba(10, 8, 20, 0.85)',
  UI_BORDER:        'rgba(200, 120, 40, 0.4)',
  UI_TEXT:          '#e8d4b4',
};
