// ━━━ COMBAT SYSTEM ━━━
import { COLORS, GROUND_Y } from '../constants';

export class CombatSystem {
  updateProjectiles(dt, engine) {
    const projectiles = engine.entities.projectiles;
    const bugs = engine.entities.bugs;
    const player = engine.entities.player;
    const infantry = engine.entities.infantry;
    const buildings = engine.entities.buildings;

    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= dt;

      // Trail
      p.trail.push({ x: p.x, y: p.y, life: 100 });
      if (p.trail.length > 5) p.trail.shift();
      p.trail.forEach(t => { t.life -= dt; });

      if (p.life <= 0) {
        projectiles.splice(i, 1);
        continue;
      }

      let hit = false;

      if (p.friendly) {
        // Hit bugs
        for (const bug of bugs) {
          if (bug.dead) continue;
          if (this._collides(p, bug)) {
            bug.takeDamage(p.damage, engine);
            hit = true;
            break;
          }
        }
      } else {
        // Hit player
        if (this._collidesEntity(p, player)) {
          player.takeDamage(p.damage, engine);
          hit = true;
        }
        // Hit infantry
        if (!hit) {
          for (const mi of infantry) {
            if (this._collidesEntity(p, mi)) {
              mi.takeDamage(p.damage, engine);
              hit = true;
              break;
            }
          }
        }
        // Hit buildings (half damage — structures are tough)
        if (!hit) {
          for (const b of buildings) {
            if (b.destroyed) continue;
            if (p.x > b.x && p.x < b.x + b.width && p.y > b.y && p.y < b.y + b.height) {
              b.hp -= p.damage * 0.5;
              hit = true;
              break;
            }
          }
        }
      }

      if (hit) {
        // Impact spark
        engine.entities.particles.push({
          x: p.x, y: p.y,
          vx: (Math.random() - 0.5) * 3,
          vy: (Math.random() - 0.5) * 3,
          life: 100, maxLife: 100,
          color: '#ffffff', size: 3,
        });
        projectiles.splice(i, 1);
      }
    }
  }

  updateGrenades(dt, engine) {
    const grenades = engine.entities.grenades;
    for (let i = grenades.length - 1; i >= 0; i--) {
      const g = grenades[i];
      g.x += g.vx;
      g.y += g.vy;
      g.vy += 0.3; // gravity
      g.vx *= 0.99;
      g.life -= dt;

      // Ground bounce
      if (g.y >= GROUND_Y) {
        g.y = GROUND_Y;
        g.vy *= -0.3;
        g.vx *= 0.7;
      }

      if (g.life <= 0) {
        // EXPLODE
        this._explodeGrenade(g, engine);
        grenades.splice(i, 1);
      }
    }
  }

  _explodeGrenade(g, engine) {
    const { bugs, particles } = engine.entities;

    // Damage bugs in radius
    for (const bug of bugs) {
      if (bug.dead) continue;
      const dx = bug.x - g.x;
      const dy = bug.y - g.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < g.radius) {
        const falloff = 1 - dist / g.radius;
        bug.takeDamage(g.damage * falloff, engine);
      }
    }

    // Big explosion FX
    engine.fx.spawnExplosion(g.x, g.y, particles);
    engine.fx.addShake(8);
  }

  _collides(projectile, entity) {
    const dx = Math.abs(projectile.x - entity.x);
    const dy = Math.abs(projectile.y - (entity.y - entity.height / 2));
    return dx < entity.width / 2 + 4 && dy < entity.height / 2 + 4;
  }

  _collidesEntity(projectile, entity) {
    const dx = Math.abs(projectile.x - entity.x);
    const dy = Math.abs(projectile.y - (entity.y - entity.height / 2));
    return dx < entity.width / 2 && dy < entity.height / 2;
  }
}