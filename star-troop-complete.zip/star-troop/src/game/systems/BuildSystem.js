// ━━━ BUILD SYSTEM ━━━
import { BUILDINGS, GROUND_Y, WORLD_WIDTH } from '../constants';

export class BuildSystem {
  constructor() {
    this.buildQueue = ['WALL', 'WALL', 'GUARD_TOWER', 'BARRACKS'];
    this.buildIndex = 0;
  }

  buildInitialBase(entities, centerX) {
    // Command Post at center
    const hq = this._createBuilding('COMMAND_POST', centerX - BUILDINGS.COMMAND_POST.width / 2);
    entities.buildings.push(hq);

    // Left wall
    const lWall = this._createBuilding('WALL', centerX - 140);
    entities.buildings.push(lWall);

    // Right wall
    const rWall = this._createBuilding('WALL', centerX + 120);
    entities.buildings.push(rWall);

    // One guard tower
    const tower = this._createBuilding('GUARD_TOWER', centerX + 60);
    entities.buildings.push(tower);
  }

  tryBuild(engine) {
    if (this.buildIndex >= this.buildQueue.length) {
      // Cycle back
      this.buildIndex = 0;
    }

    const type = this.buildQueue[this.buildIndex];
    const spec = BUILDINGS[type];
    const cost = spec.cost;

    if (engine.ore < cost) { engine.buildFailFlash = 1200; return; } // flash HUD

    const player = engine.entities.player;
    const buildX = player.x + player.facing * 50;

    // Check no overlap with existing buildings
    for (const b of engine.entities.buildings) {
      if (b.destroyed) continue;
      if (Math.abs(buildX - b.x) < b.width + 10) return;
    }

    engine.ore -= cost;
    const building = this._createBuilding(type, buildX - spec.width / 2);
    engine.entities.buildings.push(building);

    // Build FX
    for (let i = 0; i < 8; i++) {
      engine.entities.particles.push({
        x: buildX,
        y: GROUND_Y - spec.height / 2,
        vx: (Math.random() - 0.5) * 4,
        vy: -Math.random() * 3,
        life: 400 + Math.random() * 200,
        maxLife: 600,
        color: '#aaa',
        size: 2 + Math.random() * 2,
      });
    }

    this.buildIndex++;
  }

  _createBuilding(type, x) {
    const spec = BUILDINGS[type];
    return {
      type,
      x: x,
      y: GROUND_Y - spec.height,
      width: spec.width,
      height: spec.height,
      hp: spec.hp,
      maxHp: spec.hp,
      destroyed: false,
      label: spec.label,
    };
  }
}