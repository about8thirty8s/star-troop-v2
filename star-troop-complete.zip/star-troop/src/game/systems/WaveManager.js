// ━━━ WAVE MANAGER ━━━
import { WAVES, WORLD_WIDTH, CANVAS_WIDTH } from '../constants';
import { WarriorBug } from '../entities/Bug';

export class WaveManager {
  constructor() {
    this.reset();
  }

  reset() {
    this.active = false;
    this.currentWave = 0;
    this.bugsToSpawn = 0;
    this.bugsSpawned = 0;
    this.spawnTimer = 0;
    this.totalBugs = 0;
  }

  startWave(waveNum) {
    this.active = true;
    this.currentWave = waveNum;
    this.totalBugs = WAVES.BASE_COUNT + (waveNum - 1) * WAVES.SCALE_PER_WAVE;
    this.bugsToSpawn = this.totalBugs;
    this.bugsSpawned = 0;
    this.spawnTimer = 0;
  }

  endWave() {
    this.active = false;
  }

  update(dt, entities, camera) {
    if (!this.active || this.bugsToSpawn <= 0) return;

    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      // Decrease interval as wave progresses for pressure
      const interval = Math.max(WAVES.MIN_INTERVAL, WAVES.SPAWN_INTERVAL - this.currentWave * WAVES.INTERVAL_DECAY);
      this.spawnTimer = interval;

      // Spawn from left or right
      const side = Math.random() > 0.5 ? 1 : -1;
      let spawnX;
      if (side === -1) {
        spawnX = camera.x - CANVAS_WIDTH / 2 - WAVES.SPAWN_MARGIN;
      } else {
        spawnX = camera.x + CANVAS_WIDTH / 2 + WAVES.SPAWN_MARGIN;
      }

      // Clamp to world bounds
      spawnX = Math.max(50, Math.min(WORLD_WIDTH - 50, spawnX));

      const bug = new WarriorBug(spawnX);
      bug.facing = -side;
      entities.bugs.push(bug);

      this.bugsSpawned++;
      this.bugsToSpawn--;
    }
  }
}