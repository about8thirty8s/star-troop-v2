// ━━━ SQUAD IDLE STATE MACHINE ━━━
// When the player stops, units cycle through idle animations.
// Each unit has a randomly seeded timer so they don't all fidget at once.
// States: ALERT → SCAN → FIDGET → ALERT (repeating)
// Class-specific fidget variants drive sprite selection — zero extra logic.

const IDLE_STATES = {
  ALERT:  'idle_alert',
  SCAN:   'idle_scan',
  FIDGET: 'idle_fidget',
};

const TIMERS = {
  ALERT_MIN:  3500,
  ALERT_MAX:  7000,
  SCAN_MIN:   1800,
  SCAN_MAX:   3500,
  FIDGET_MIN: 900,
  FIDGET_MAX: 1800,
};

// Class-specific fidget animation key — renderer picks sprite set from this string
const FIDGET_VARIANTS = {
  infantry:  'check_rifle',   // checks rifle, shifts stance
  scientist: 'datapad',       // pulls out datapad, taps it
  miner:     'tap_tool',      // taps tool on ground twice
  medic:     'check_kit',     // opens medkit, closes it
  pilot:     'look_sky',      // crosses arms, looks at sky
};

function rand(min, max) {
  return min + Math.random() * (max - min);
}

export class SquadIdle {
  // Called once when a unit is created/rescued — seeds their idle timers
  initUnit(unit) {
    unit.idleState     = IDLE_STATES.ALERT;
    unit.idleTimer     = rand(TIMERS.ALERT_MIN, TIMERS.ALERT_MAX);
    unit.idleVariant   = FIDGET_VARIANTS[unit.role || 'infantry'];
    unit.scanDir       = 1; // 1 or -1 — which way they're scanning
    unit.playerStopTimer = unit.playerStopTimer || 0;
  }

  update(infantry, dt) {
    for (const unit of infantry) {
      if (unit.state === 'waiting' || unit.hp <= 0) continue;
      // Only run idle machine when player is stationary
      if ((unit.playerStopTimer || 0) < 1200) {
        // Player moving — stay alert, don't advance idle cycle
        unit.idleState = IDLE_STATES.ALERT;
        // Don't reset timer here — Formation owns playerStopTimer
        continue;
      }

      unit.idleTimer -= dt;
      if (unit.idleTimer > 0) continue;

      // Transition
      switch (unit.idleState) {
        case IDLE_STATES.ALERT:
          unit.idleState = IDLE_STATES.SCAN;
          unit.idleTimer = rand(TIMERS.SCAN_MIN, TIMERS.SCAN_MAX);
          unit.scanDir   = Math.random() > 0.5 ? 1 : -1;
          break;

        case IDLE_STATES.SCAN:
          unit.idleState = IDLE_STATES.FIDGET;
          unit.idleTimer = rand(TIMERS.FIDGET_MIN, TIMERS.FIDGET_MAX);
          break;

        case IDLE_STATES.FIDGET:
          unit.idleState = IDLE_STATES.ALERT;
          unit.idleTimer = rand(TIMERS.ALERT_MIN, TIMERS.ALERT_MAX);
          break;
      }
    }
  }

  // Returns the current animation key for a unit — used by renderer
  getAnimKey(unit) {
    if (unit.state === 'waiting')  return 'idle_alert';
    if (unit.state === 'hold')     return 'idle_alert';
    return unit.idleState || IDLE_STATES.ALERT;
  }
}
