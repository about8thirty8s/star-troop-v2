// ━━━ AI SYSTEM ━━━
// Handles bug targeting + movement, and infantry combat decision-making.
//
// Infantry state machine (owned here, respects SquadFormation assignments):
//   waiting  → skip entirely (at lifepod, not yet rescued)
//   follow   → SquadFormation owns position. We only handle firing.
//   hold     → Navigate to defenseX assigned by SquadFormation.disperseToDefensePoints()
//              then stand and shoot anything in ENGAGE_RANGE.
//   engage   → Override position to stand and fire at nearest bug.
//              Reverts to 'hold' or 'follow' when no bugs nearby.

import { WARRIOR_BUG, MI, WORLD_WIDTH } from '../constants';

// How far an MI will shoot at bugs from their defense point
// How close to defenseX counts as "at post"
// Fire rate variance so a squad of MI doesn't all shoot simultaneously

export class AISystem {

  // ── BUG AI ───────────────────────────────────────────────────────────────
  updateBug(bug, dt, engine) {
    if (bug.dead) return;

    const player    = engine.entities.player;
    const buildings = engine.entities.buildings;
    const infantry  = engine.entities.infantry;

    // ── Target selection ──
    // Priority: nearest building → nearest infantry within 200px → player within 150px
    let nearest     = null;
    let nearestDist = Infinity;

    for (const b of buildings) {
      if (b.destroyed) continue;
      const dist = Math.abs((b.x + b.width / 2) - bug.x);
      if (dist < nearestDist) {
        nearestDist = dist;
        nearest = { x: b.x + b.width / 2, y: b.y + b.height / 2, entity: b, type: 'building' };
      }
    }

    for (const mi of infantry) {
      if (mi.hp <= 0 || mi.state === 'waiting') continue;
      const dist = Math.abs(mi.x - bug.x);
      if (dist < nearestDist && dist < 200) {
        nearestDist = dist;
        nearest = { x: mi.x, y: mi.y, entity: mi, type: 'infantry' };
      }
    }

    const pDist = Math.abs(player.x - bug.x);
    if (pDist < nearestDist && pDist < 150) {
      nearestDist = pDist;
      nearest = { x: player.x, y: player.y, entity: player, type: 'player' };
    }

    // Default: charge toward world centre (base)
    if (!nearest) {
      const centerX = WORLD_WIDTH / 2;
      bug.facing = bug.x < centerX ? 1 : -1;
      bug.vx = bug.facing * bug.speed;
      return;
    }

    const dx = nearest.x - bug.x;
    bug.facing = dx > 0 ? 1 : -1;

    if (nearestDist > WARRIOR_BUG.MELEE_RANGE) {
      // Close distance
      bug.vx = bug.facing * bug.speed;
    } else {
      // In melee range — stop and attack
      bug.vx = 0;
      if (bug.attackTimer <= 0) {
        bug.attackTimer = WARRIOR_BUG.ATTACK_RATE;

        if (nearest.type === 'building') {
          nearest.entity.hp -= bug.damage;
        } else {
          nearest.entity.takeDamage(bug.damage, engine);
        }

        // Claw slash particles
        for (let i = 0; i < 3; i++) {
          engine.entities.particles.push({
            x: bug.x + bug.facing * 10,
            y: bug.y - bug.height / 2,
            vx: bug.facing * (1.5 + Math.random() * 2),
            vy: -0.5 - Math.random() * 1.5,
            life: 120 + Math.random() * 80,
            maxLife: 200,
            color: '#ff3322',
            size: 2 + Math.random() * 2,
          });
        }
      }
    }
  }

  // ── INFANTRY AI ──────────────────────────────────────────────────────────
  updateInfantry(mi, dt, engine) {
    // Waiting at pod — SquadFormation hasn't rescued yet, skip entirely
    if (mi.state === 'waiting') return;
    if (mi.hp <= 0) return;

    const bugs   = engine.entities.bugs;
    const player = engine.entities.player;

    // ── Step 1: find nearest living bug within engage range ──
    let nearestBug  = null;
    let nearestDist = Infinity;

    for (const bug of bugs) {
      if (bug.dead) continue;
      const dist = Math.abs(bug.x - mi.x);
      if (dist < MI.ENGAGE_RANGE && dist < nearestDist) {
        nearestDist = dist;
        nearestBug  = bug;
      }
    }

    // ── Step 2: ENGAGE — fires at nearest bug regardless of state ──
    // This fires from BOTH hold and follow states — infantry always shoot
    // at targets of opportunity without abandoning their position.
    if (nearestBug) {
      mi.fire(nearestBug.x, engine);
      // Face the bug
      mi.facing = nearestBug.x > mi.x ? 1 : -1;

      // In follow state: stand still while firing, SquadFormation handles drift
      if (mi.state === 'follow') {
        mi.vx = 0;
      }
      // In hold state: plant and fire — don't move to bug, hold the line
      if (mi.state === 'hold') {
        mi.vx = 0;
        // Inch slightly toward bug if it gets very close (< 80px) — don't let it eat us
        if (nearestDist < MI.MELEE_THRESHOLD) {
          mi.vx = mi.facing * mi.speed * 0.4;
        }
      }
      return; // firing — movement handled above
    }

    // ── Step 3: No bug in range — state-based positioning ──
    switch (mi.state) {

      case 'hold': {
        // Navigate to assigned defenseX (set by SquadFormation.disperseToDefensePoints)
        const targetX = mi.defenseX !== null && mi.defenseX !== undefined
          ? mi.defenseX
          : player.x; // fallback if somehow no defense point assigned

        const dx = targetX - mi.x;

        if (Math.abs(dx) > MI.AT_POST_THRESHOLD) {
          // Move to post
          mi.facing = dx > 0 ? 1 : -1;
          mi.vx = mi.facing * mi.speed * MI.HOLD_SPEED_MULT;
        } else {
          // At post — stand, face outward (away from base centre)
          mi.vx = 0;
          const centreX = WORLD_WIDTH / 2;
          mi.facing = mi.x < centreX ? -1 : 1; // face the direction bugs come from
        }
        break;
      }

      case 'follow': {
        // SquadFormation owns this — just zero velocity so formation lerp can work cleanly
        // (formation update sets x directly via lerp, not vx)
        mi.vx = 0;
        break;
      }

      case 'engage': {
        // Bug that was being engaged is now dead — revert to appropriate state
        const isNight = engine.dayNight.phase === 'night' || engine.dayNight.phase === 'dusk';
        mi.state = isNight ? 'hold' : 'follow';
        mi.vx = 0;
        break;
      }
    }
  }
}
