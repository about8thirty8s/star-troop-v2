// ━━━ CAMERA SYSTEM ━━━
// Always follows the player. Smooth lerp, clamped to world edges.
// Look-ahead only kicks in after player has been facing the same direction
// for LOOK_AHEAD_SETTLE_MS — prevents the 160px lurch on quick turns.
import { CANVAS_WIDTH, WORLD_WIDTH } from '../constants';

const SMOOTHING           = 0.10;
const LOOK_AHEAD_PX       = 70;    // max px ahead in direction of travel
const LOOK_AHEAD_SETTLE   = 0.18;  // lerp rate for look-ahead direction (slow = no lurch)

export class CameraSystem {
  constructor() {
    this.x          = 0;
    this.targetX    = 0;
    this._lookDir   = 0;   // smoothed look-ahead direction (-1..1)
    this._lookAmt   = 0;   // smoothed look-ahead amount (0..LOOK_AHEAD_PX)
  }

  init(playerX) {
    this.x       = playerX;
    this.targetX = playerX;
    this._lookDir = 0;
    this._lookAmt = 0;
  }

  follow(playerX, dt, playerFacing = 1, playerMoving = false) {
    // Only apply look-ahead when player is actually moving
    const targetLookAmt = playerMoving ? LOOK_AHEAD_PX : 0;
    this._lookDir += (playerFacing  - this._lookDir) * LOOK_AHEAD_SETTLE;
    this._lookAmt += (targetLookAmt - this._lookAmt) * LOOK_AHEAD_SETTLE;

    this.targetX = playerX + this._lookDir * this._lookAmt;
    this.x      += (this.targetX - this.x) * SMOOTHING;

    const halfScreen = CANVAS_WIDTH / 2;
    this.x = Math.max(halfScreen, Math.min(WORLD_WIDTH - halfScreen, this.x));
  }

  worldToScreen(worldX) {
    return worldX - this.x + CANVAS_WIDTH / 2;
  }

  isVisible(worldX, margin = 120) {
    const screenX = this.worldToScreen(worldX);
    return screenX > -margin && screenX < CANVAS_WIDTH + margin;
  }
}
