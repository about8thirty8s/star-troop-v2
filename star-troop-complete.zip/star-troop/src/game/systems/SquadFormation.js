// ━━━ SQUAD FORMATION SYSTEM ━━━
// Assigns each rescued unit a unique slot offset behind the player.
// Slots stagger above/below so units form a loose wedge — never a conga line.
// Each unit has unique sine drift so nobody moves identically.
// Night transition: units break formation → pathfind to wall defensePoints.

// Slot offsets [dx, dy] — staggered so they fan into a loose wedge
const SLOTS = [
  { dx: -32, dy:   0 },   // 0 — just behind
  { dx: -58, dy:   5 },   // 1 — further, slightly lower
  { dx: -54, dy:  -6 },   // 2 — further, slightly higher
  { dx: -84, dy:   4 },   // 3 — back-left, offset down
  { dx: -80, dy:  -8 },   // 4 — back-left, offset up
  { dx: -110,dy:   0 },   // 5 — far back, centre
];

const LERP_SPEED   = 0.07;   // base lerp rate toward slot
const SPEED_VARY   = 0.03;   // ± variance so units don't arrive simultaneously

export class SquadFormation {
  constructor() {
    this._usedSlots = new Set();
  }

  // Called when a new survivor is rescued — assigns the next free slot
  assignSlot(unit, allInfantry) {
    // Find lowest free slot index
    const usedIndices = new Set(
      allInfantry.filter(m => m.slotIndex !== undefined && m.state === 'follow')
                 .map(m => m.slotIndex)
    );
    let idx = 0;
    while (usedIndices.has(idx)) idx++;

    unit.slotIndex  = idx;
    // Unique drift params — assigned once, persist for life of unit
    unit.idlePhase  = Math.random() * Math.PI * 2;
    unit.idleSpeedX = 0.38 + Math.random() * 0.28;
    unit.idleSpeedY = 0.22 + Math.random() * 0.18;
    unit.idleAmpX   = 1.4  + Math.random() * 1.4;
    unit.idleAmpY   = 0.8  + Math.random() * 0.8;
    unit.lerpSpeed  = LERP_SPEED + (Math.random() - 0.5) * SPEED_VARY;
    unit.playerStopTimer = 0;
  }

  // Called every frame from engine
  update(player, infantry, dt, time) {
    const phase = player._phase || 'day';
    const playerStopped = Math.abs(player.vx) < 0.15;

    for (const unit of infantry) {
      if (unit.state !== 'follow') continue;
      if (unit.slotIndex === undefined) this.assignSlot(unit, infantry);

      // Track how long player has been stationary
      if (playerStopped) {
        unit.playerStopTimer = (unit.playerStopTimer || 0) + dt;
      } else {
        unit.playerStopTimer = 0;
      }

      const slot = SLOTS[Math.min(unit.slotIndex, SLOTS.length - 1)];

      // Flip slot dx based on player facing
      const facing = player.facing || 1;
      const targetX = player.x + slot.dx * facing;
      const targetY = player.y + slot.dy;

      // Lerp toward slot — only move horizontally if player is moving or we're far off
      const distX = Math.abs(unit.x - targetX);
      const distY = Math.abs(unit.y - targetY);

      if (distX > 2 || !playerStopped) {
        unit.x += (targetX - unit.x) * unit.lerpSpeed;
      }
      if (distY > 1) {
        unit.y += (targetY - unit.y) * unit.lerpSpeed;
      }

      // Idle drift when player has stopped for > 1.2s
      if (unit.playerStopTimer > 1200) {
        const t = time / 1000;
        unit.x += Math.sin(t * unit.idleSpeedX + unit.idlePhase) * unit.idleAmpX * (dt / 16.667);
        unit.y += Math.cos(t * unit.idleSpeedY + unit.idlePhase + 1.1) * unit.idleAmpY * (dt / 16.667);
      }

      // Face toward nearest threat (bug) or forward
      // (handled by AISystem — just ensure facing is set)
    }
  }

  // Called on 'night' phase start — distribute units to wall defensePoints
  disperseToDefensePoints(infantry, buildings) {
    // Collect all unclaimed defensePoints from walls and towers
    const points = [];
    for (const b of buildings) {
      if (b.destroyed) continue;
      if (b.type === 'WALL' || b.type === 'GUARD_TOWER') {
        // Left and right of each wall section
        points.push({ x: b.x,               y: b.y, claimed: false, buildingRef: b });
        points.push({ x: b.x + b.width + 8, y: b.y, claimed: false, buildingRef: b });
      }
    }

    for (const unit of infantry) {
      if (!unit.alive && unit.hp <= 0) continue;
      if (unit.state === 'waiting') continue;

      // Find nearest unclaimed point
      let best = null, bestDist = Infinity;
      for (const pt of points) {
        if (pt.claimed) continue;
        const d = Math.abs(unit.x - pt.x);
        if (d < bestDist) { bestDist = d; best = pt; }
      }
      if (best) {
        best.claimed = true;
        unit.defenseX = best.x;
        unit.defenseY = best.y;
        unit.state    = 'hold';
        unit.slotIndex = undefined; // release slot
      }
    }
  }

  // Called on 'day' phase start — pull units back into formation
  reformFormation(infantry) {
    let idx = 0;
    for (const unit of infantry) {
      if (unit.hp <= 0) continue;
      unit.state    = 'follow';
      unit.defenseX = undefined;
      unit.defenseY = undefined;
      this.assignSlot(unit, infantry);
      idx++;
    }
  }
}
