// ━━━ FX SYSTEM ━━━
import { COLORS, CANVAS_WIDTH, CANVAS_HEIGHT } from '../constants';

export class FXSystem {
  constructor() {
    this.shakeX         = 0;
    this.shakeY         = 0;
    this.shakeIntensity = 0;
    // Flash (lifepod ship explosion)
    this.flash = null;
  }

  // ── Screen shake ──────────────────────────────────────────────────────────
  addShake(intensity) {
    // Hard cap so it never becomes unplayable
    this.shakeIntensity = Math.min(this.shakeIntensity + intensity, 18);
  }

  triggerShake(intensity = 4, durationMs = 250) {
    this.addShake(intensity);
  }

  updateShake(dt) {
    if (this.shakeIntensity > 0) {
      this.shakeX = (Math.random() - 0.5) * this.shakeIntensity;
      this.shakeY = (Math.random() - 0.5) * this.shakeIntensity * 0.5;
      // Decay — faster decay at low intensity (snap back), slower at high (rumble lingers)
      const decayRate = this.shakeIntensity > 8 ? 0.88 : 0.80;
      this.shakeIntensity *= decayRate;
      if (this.shakeIntensity < 0.1) this.shakeIntensity = 0;
    } else {
      this.shakeX = 0;
      this.shakeY = 0;
    }
  }

  // ── Atmospheric flash (lifepod) ───────────────────────────────────────────
  triggerFlash(color = '#ff8833', alpha = 0.25, durationMs = 180) {
    this.flash = { color, alpha, duration: durationMs, timer: durationMs };
  }

  // ── Crosshair ─────────────────────────────────────────────────────────────
  // Called by Renderer — draws aim cursor at screen mouse position
  drawCrosshair(ctx, mouseX, mouseY, sustainRatio = 0) {
    // Crosshair grows slightly with heat (spread visualisation)
    const base   = 8;
    const spread = base + sustainRatio * 6;
    const gap    = 3 + sustainRatio * 2;
    const alpha  = 0.85 - sustainRatio * 0.2;
    // Colour shifts red-orange with heat
    const r = Math.round(80  + sustainRatio * 175);
    const g = Math.round(220 - sustainRatio * 140);
    const b = 60;
    const color = `rgba(${r},${g},${b},${alpha})`;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth   = 1.5;
    ctx.shadowColor = color;
    ctx.shadowBlur  = 4;

    // Four lines — horizontal
    ctx.beginPath();
    ctx.moveTo(mouseX - spread, mouseY);
    ctx.lineTo(mouseX - gap,    mouseY);
    ctx.moveTo(mouseX + gap,    mouseY);
    ctx.lineTo(mouseX + spread, mouseY);
    // Vertical
    ctx.moveTo(mouseX, mouseY - spread);
    ctx.lineTo(mouseX, mouseY - gap);
    ctx.moveTo(mouseX, mouseY + gap);
    ctx.lineTo(mouseX, mouseY + spread);
    ctx.stroke();

    // Centre dot
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(mouseX, mouseY, 1.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // ── Particles ─────────────────────────────────────────────────────────────
  updateParticles(dt, particles) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      if (!p.text) {
        p.x  += p.vx;
        p.y  += p.vy;
        p.vy += 0.05; // slight gravity on particles
        p.vx *= 0.97;
      } else {
        p.y += p.vy; // float text just rises
      }
      p.life -= dt;
      if (p.life <= 0) particles.splice(i, 1);
    }
  }

  spawnHitFX(x, y, color, particles) {
    for (let i = 0; i < 5; i++) {
      particles.push({
        x, y,
        vx: (Math.random() - 0.5) * 4,
        vy: -Math.random() * 3,
        life: 200 + Math.random() * 150,
        maxLife: 350,
        color,
        size: 2 + Math.random() * 2,
      });
    }
  }

  spawnPickupFX(x, y, color, particles) {
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      particles.push({
        x, y,
        vx: Math.cos(angle) * (1.5 + Math.random() * 2),
        vy: Math.sin(angle) * (1.5 + Math.random() * 2) - 1,
        life: 300 + Math.random() * 200,
        maxLife: 500,
        color,
        size: 2 + Math.random() * 2,
      });
    }
  }

  spawnExplosion(x, y, particles) {
    for (let i = 0; i < 24; i++) {
      const angle  = (i / 24) * Math.PI * 2;
      const speed  = 2 + Math.random() * 5;
      particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        life: 500 + Math.random() * 400,
        maxLife: 900,
        color: Math.random() > 0.4 ? COLORS.EXPLOSION : '#ffdd44',
        size: 3 + Math.random() * 4,
      });
    }
    // Smoke puffs
    for (let i = 0; i < 8; i++) {
      particles.push({
        x: x + (Math.random() - 0.5) * 20,
        y: y + (Math.random() - 0.5) * 20,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -0.5 - Math.random() * 1.5,
        life: 800 + Math.random() * 400,
        maxLife: 1200,
        color: '#555555',
        size: 6 + Math.random() * 6,
      });
    }
  }

  spawnDeathFX(x, y, color, particles) {
    for (let i = 0; i < 10; i++) {
      particles.push({
        x, y,
        vx: (Math.random() - 0.5) * 5,
        vy: -Math.random() * 4,
        life: 400 + Math.random() * 300,
        maxLife: 700,
        color,
        size: 2 + Math.random() * 3,
      });
    }
  }
  spawnBugDeath(x, y, particles) {
    // Green blood burst + body chunks
    for (let i = 0; i < 10; i++) {
      const angle = (i / 10) * Math.PI * 2;
      particles.push({
        x, y,
        vx: Math.cos(angle) * (1 + Math.random() * 3),
        vy: Math.sin(angle) * (1 + Math.random() * 3) - 1,
        life: 350 + Math.random() * 250,
        maxLife: 600,
        color: Math.random() > 0.4 ? '#1a8a2a' : '#0a5a18',
        size: 2 + Math.random() * 3,
      });
    }
    // Carapace shards
    for (let i = 0; i < 5; i++) {
      particles.push({
        x: x + (Math.random() - 0.5) * 10,
        y,
        vx: (Math.random() - 0.5) * 4,
        vy: -(1 + Math.random() * 3),
        life: 500 + Math.random() * 300,
        maxLife: 800,
        color: '#2a1a0a',
        size: 3 + Math.random() * 3,
      });
    }
  }

}