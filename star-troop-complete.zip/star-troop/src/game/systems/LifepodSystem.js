// ━━━ LIFEPOD RESCUE SYSTEM ━━━
// Ship explodes in upper atmosphere → pods arc down → smoke column marks landing.
// Player sees off-screen directional arrow → travels to rescue the survivor.
//
// States: INCOMING → DESCENDING → IMPACT → LANDED → SURVIVOR_READY → RESCUED
//
// Smoke trail = persistent polyline (NOT particles) — cheap, always readable.
// Landing smoke column = capped 10 particles max.

import { CANVAS_WIDTH, CANVAS_HEIGHT, WORLD_WIDTH, GROUND_Y } from '../constants';
import { MobileInfantry } from '../entities/MobileInfantry';

const LIFEPOD_CONFIG = {
  // Spawn chance per day (checked at day start)
  daySpawnChance: 0.75,
  minPerDay: 1,
  maxPerDay: 2,
  // How long the pod takes to fall (ms)
  descentDuration: 3800,
  // Horizontal scatter from spawn X (left or right wing)
  lateralDriftRange: 600,
  // Trail
  smokeTrailFadeMs: 28000,
  smokeTrailSampleInterval: 4, // frames between trail point samples
  // Landing column
  columnParticleMax: 10,
  // Rescue
  rescueRadius: 60,
  // Off-screen arrow
  arrowFadeMs: 50000,
};

export class LifepodSystem {
  constructor() {
    this.pods     = [];   // active pod objects
    this.frameCount = 0;
    this._nextDaySpawn = true; // spawn on first day
  }

  // Call at day start
  onDayStart(engine) {
    if (!this._nextDaySpawn) {
      this._nextDaySpawn = Math.random() < LIFEPOD_CONFIG.daySpawnChance;
      if (!this._nextDaySpawn) return;
    }
    this._nextDaySpawn = false;

    const count = LIFEPOD_CONFIG.minPerDay +
      Math.floor(Math.random() * (LIFEPOD_CONFIG.maxPerDay - LIFEPOD_CONFIG.minPerDay + 1));

    // Queue pods with game-time delays (pause-safe)
    for (let i = 0; i < count; i++) {
      this._podQueue = this._podQueue || [];
      this._podQueue.push({ delay: i * 1800, engine });
    }
  }

  _spawnPod(engine) {
    const centerX = WORLD_WIDTH / 2;
    // Spawn in left or right wing, away from base
    const side = Math.random() > 0.5 ? 1 : -1;
    const landX = centerX + side * (800 + Math.random() * LIFEPOD_CONFIG.lateralDriftRange);
    const clampedX = Math.max(150, Math.min(WORLD_WIDTH - 150, landX));

    // Entry point — top of screen, slight horizontal offset for arc feel
    const entryX = clampedX + (Math.random() - 0.5) * 300;

    const pod = {
      // Identity
      id: Math.random().toString(36).slice(2),
      // Position (current)
      x: entryX,
      y: -60,
      // Target landing position
      landX: clampedX,
      landY: GROUND_Y - 12,
      // Dimensions
      width: 18,
      height: 24,
      // State
      state: 'DESCENDING',  // DESCENDING | IMPACT | LANDED | SURVIVOR_READY | RESCUED
      // Descent progress 0..1
      progress: 0,
      descentDuration: LIFEPOD_CONFIG.descentDuration,
      descentTimer: 0,
      // Smoke trail — polyline of {x,y} points, NOT particles
      trail: [],
      trailTimer: 0,
      trailAge: 0,          // ms since landing (for fade)
      // Landing column particles
      column: [],
      columnTimer: 0,
      // Arrow
      arrowAge: 0,
      // Survivor spawned at this pod?
      survivorSpawned: false,
    };

    // Flash: ship explosion in upper atmosphere
    this._spawnAtmosphereFlash(engine, entryX);

    this.pods.push(pod);
  }

  _spawnAtmosphereFlash(engine, x) {
    // Brief bright flash particles near top of screen (not world-positioned — screen space)
    for (let i = 0; i < 20; i++) {
      engine.entities.particles.push({
        x: x,
        y: 40 + Math.random() * 60,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5,
        life: 300 + Math.random() * 400,
        maxLife: 700,
        color: Math.random() > 0.5 ? '#ff9944' : '#ffdd88',
        size: 2 + Math.random() * 4,
        _screenSpace: true,  // rendered in screen coords
      });
    }
    // Screen flash
    engine.fx.triggerFlash('#ff8833', 0.18, 200);
  }

  update(dt, engine) {
    this.frameCount++;
    // Drain pod spawn queue (pause-safe alternative to setTimeout)
    if (this._podQueue && this._podQueue.length > 0) {
      this._podQueue = this._podQueue || [];
      for (let i = this._podQueue.length - 1; i >= 0; i--) {
        const q = this._podQueue[i];
        q.delay -= dt;
        if (q.delay <= 0) {
          this._spawnPod(q.engine);
          this._podQueue.splice(i, 1);
        }
      }
    }

    for (let i = this.pods.length - 1; i >= 0; i--) {
      const pod = this.pods[i];
      this._updatePod(pod, dt, engine);

      // Clean up long-finished pods
      if (pod.state === 'RESCUED' && pod.trailAge > LIFEPOD_CONFIG.smokeTrailFadeMs) {
        this.pods.splice(i, 1);
      }
    }
  }

  _updatePod(pod, dt, engine) {
    switch (pod.state) {

      case 'DESCENDING': {
        pod.descentTimer += dt;
        pod.progress = Math.min(1, pod.descentTimer / pod.descentDuration);

        // Arc interpolation: easeIn on X (drifts), accelerate on Y
        const t = pod.progress;
        pod.x = pod.x + (pod.landX - pod.x) * 0.04;  // lateral drag
        pod.y = -60 + (pod.landY + 60) * (t * t);    // accelerating drop

        // Sample trail every N frames
        pod.trailTimer++;
        if (pod.trailTimer >= LIFEPOD_CONFIG.smokeTrailSampleInterval) {
          pod.trailTimer = 0;
          pod.trail.push({ x: pod.x, y: pod.y });
          // Cap trail points (5s at 60fps / 4 = ~75 points)
          if (pod.trail.length > 90) pod.trail.shift();
        }

        if (pod.progress >= 1) {
          pod.x = pod.landX;
          pod.y = pod.landY;
          pod.state = 'IMPACT';
          this._doImpact(pod, engine);
        }
        break;
      }

      case 'IMPACT': {
        // Brief pause for impact FX, then transition
        pod._impactTimer = (pod._impactTimer || 0) + dt;
        pod.trailAge += dt;
        this._updateColumn(pod, dt, engine);
        if (pod._impactTimer > 800) {
          pod.state = 'SURVIVOR_READY';
          this._spawnSurvivor(pod, engine);
        }
        break;
      }

      case 'LANDED':
      case 'SURVIVOR_READY': {
        pod.trailAge += dt;
        pod.arrowAge += dt;
        this._updateColumn(pod, dt, engine);

        // Check rescue distance
        if (!pod.survivorSpawned) break;
        const player = engine.entities.player;
        const dx = player.x - pod.landX;
        const dy = player.y - pod.landY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < LIFEPOD_CONFIG.rescueRadius) {
          this._doRescue(pod, engine);
        }
        break;
      }

      case 'RESCUED': {
        pod.trailAge += dt;
        this._updateColumn(pod, dt, engine);
        break;
      }
    }
  }

  _doImpact(pod, engine) {
    // Screen shake
    engine.fx.triggerShake(5, 300);

    // Impact dust burst
    for (let i = 0; i < 18; i++) {
      const angle = (i / 18) * Math.PI * 2;
      engine.entities.particles.push({
        x: pod.landX,
        y: pod.landY,
        vx: Math.cos(angle) * (2 + Math.random() * 4),
        vy: Math.sin(angle) * (1 + Math.random() * 3) - 2,
        life: 600 + Math.random() * 400,
        maxLife: 1000,
        color: Math.random() > 0.5 ? '#c8a870' : '#886644',
        size: 2 + Math.random() * 3,
      });
    }

    // Seed the smoke column
    pod.column = [];
    pod.columnTimer = 0;
  }

  _updateColumn(pod, dt, engine) {
    // Rising smoke column at landing site
    pod.columnTimer += dt;
    if (pod.columnTimer > 280 && pod.column.length < LIFEPOD_CONFIG.columnParticleMax) {
      pod.columnTimer = 0;
      pod.column.push({
        x: pod.landX + (Math.random() - 0.5) * 8,
        y: pod.landY - 8,
        vy: -(0.3 + Math.random() * 0.4),
        life: 2200 + Math.random() * 800,
        maxLife: 3000,
        size: 3 + Math.random() * 3,
        alpha: 0.55,
      });
    }

    for (let i = pod.column.length - 1; i >= 0; i--) {
      const p = pod.column[i];
      p.y  += p.vy;
      p.x  += (Math.random() - 0.5) * 0.3;
      p.life -= dt;
      p.size += 0.012;
      if (p.life <= 0) pod.column.splice(i, 1);
    }
  }

  _spawnSurvivor(pod, engine) {
    if (pod.survivorSpawned) return;
    pod.survivorSpawned = true;
    const mi = new MobileInfantry(pod.landX + 20, GROUND_Y); // always spawn on ground
    mi.state = 'waiting'; // stands at pod, won't follow until rescued
    mi.podId = pod.id;
    engine.entities.infantry.push(mi);
  }

  _doRescue(pod, engine) {
    pod.state = 'RESCUED';
    // Find the waiting infantry and set them to follow
    for (const mi of engine.entities.infantry) {
      if (mi.podId === pod.id && mi.state === 'waiting') {
        mi.state = 'follow';
        mi.podId = null;
        // Assign formation slot
        engine.squadFormation.assignSlot(mi, engine.entities.infantry);
        break;
      }
    }
    // Rescue FX
    for (let i = 0; i < 12; i++) {
      engine.entities.particles.push({
        x: pod.landX,
        y: pod.landY - 20,
        vx: (Math.random() - 0.5) * 4,
        vy: -1 - Math.random() * 3,
        life: 500 + Math.random() * 300,
        maxLife: 800,
        color: '#88ff88',
        size: 1.5 + Math.random() * 2,
      });
    }
  }

  // ── RENDER ────────────────────────────────────────────────────────────────
  render(ctx, engine) {
    const cam = engine.camera;

    for (const pod of this.pods) {
      if (pod.state === 'RESCUED' && pod.trailAge > LIFEPOD_CONFIG.smokeTrailFadeMs) continue;

      // Draw smoke trail (polyline)
      if (pod.trail.length > 1) {
        const ageFade = pod.state !== 'DESCENDING'
          ? Math.max(0, 1 - pod.trailAge / LIFEPOD_CONFIG.smokeTrailFadeMs)
          : 1;
        ctx.save();
        ctx.strokeStyle = `rgba(180,160,130,${0.45 * ageFade})`;
        ctx.lineWidth = 2.5;
        ctx.setLineDash([4, 5]);
        ctx.beginPath();
        for (let i = 0; i < pod.trail.length; i++) {
          const sx = cam.worldToScreen(pod.trail[i].x);
          const sy = pod.trail[i].y; // y is screen-relative during descent
          if (i === 0) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }

      // Draw landing smoke column
      for (const p of pod.column) {
        if (!cam.isVisible(p.x, 20)) continue;
        const sx = cam.worldToScreen(p.x);
        const lifeRatio = p.life / p.maxLife;
        ctx.save();
        ctx.globalAlpha = p.alpha * lifeRatio * 0.7;
        ctx.fillStyle = '#b0a090';
        ctx.beginPath();
        ctx.arc(sx, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Draw pod (if not yet rescued)
      if (pod.state !== 'RESCUED') {
        const sx = cam.worldToScreen(pod.x);
        ctx.save();
        ctx.fillStyle = '#8899aa';
        ctx.strokeStyle = '#aabbcc';
        ctx.lineWidth = 1;
        // Capsule shape
        ctx.beginPath();
        ctx.roundRect(sx - pod.width/2, pod.y - pod.height, pod.width, pod.height, 4);
        ctx.fill();
        ctx.stroke();
        // Heat stripe
        ctx.fillStyle = 'rgba(255,120,40,0.5)';
        ctx.fillRect(sx - pod.width/2, pod.y - pod.height, pod.width, 4);
        ctx.restore();
      }

      // Off-screen directional arrow (when pod is off-screen and not rescued)
      if (pod.state === 'SURVIVOR_READY' || pod.state === 'LANDED') {
        const sx = cam.worldToScreen(pod.landX);
        if (sx < 0 || sx > CANVAS_WIDTH) {
          const arrowFade = Math.max(0, 1 - pod.arrowAge / LIFEPOD_CONFIG.arrowFadeMs);
          this._drawEdgeArrow(ctx, pod.landX, cam, arrowFade);
        }
      }
    }
  }

  _drawEdgeArrow(ctx, worldX, cam, alpha) {
    const sx = cam.worldToScreen(worldX);
    const margin = 24;
    const clampedX = Math.max(margin, Math.min(CANVAS_WIDTH - margin, sx));
    const arrowX = sx < 0 ? margin : CANVAS_WIDTH - margin;
    const arrowY = CANVAS_HEIGHT * 0.42;
    const dir = sx < 0 ? -1 : 1;

    ctx.save();
    ctx.globalAlpha = alpha * (0.7 + Math.sin(Date.now() * 0.004) * 0.3);
    ctx.fillStyle = '#88ff88';
    ctx.strokeStyle = '#004400';
    ctx.lineWidth = 1;
    // Arrow triangle
    ctx.beginPath();
    ctx.moveTo(arrowX + dir * 14, arrowY);
    ctx.lineTo(arrowX + dir * 2,  arrowY - 9);
    ctx.lineTo(arrowX + dir * 2,  arrowY + 9);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Label
    ctx.font = 'bold 8px monospace';
    ctx.fillStyle = '#aaffaa';
    ctx.fillText('POD', arrowX + dir * (dir > 0 ? -22 : 16), arrowY + 3);
    ctx.restore();
  }
}
