// ━━━ DAY/NIGHT CYCLE SYSTEM ━━━
import { DAY_NIGHT } from '../constants';

export class DayNightSystem {
  constructor() {
    this.reset();
  }

  reset() {
    this.time = 0;
    this.phase = 'day'; // day, dusk, night, dawn
    this.phaseTime = 0;
    this.dayCount = 1;
    this.darkness = 0; // 0 = full day, 1 = full night
  }

  update(dt) {
    this.phaseTime += dt;

    switch (this.phase) {
      case 'day':
        this.darkness = 0;
        if (this.phaseTime >= DAY_NIGHT.DAY_DURATION) {
          this.phase = 'dusk';
          this.phaseTime = 0;
        }
        break;

      case 'dusk':
        this.darkness = Math.min(1, this.phaseTime / DAY_NIGHT.DUSK_TRANSITION);
        if (this.phaseTime >= DAY_NIGHT.DUSK_TRANSITION) {
          this.phase = 'night';
          this.phaseTime = 0;
        }
        break;

      case 'night':
        this.darkness = 1;
        if (this.phaseTime >= DAY_NIGHT.NIGHT_DURATION) {
          this.phase = 'dawn';
          this.phaseTime = 0;
        }
        break;

      case 'dawn':
        this.darkness = Math.max(0, 1 - this.phaseTime / DAY_NIGHT.DAWN_TRANSITION);
        if (this.phaseTime >= DAY_NIGHT.DAWN_TRANSITION) {
          this.phase = 'day';
          this.phaseTime = 0;
          this.dayCount++;
        }
        break;
    }
  }

  getNightProgress() {
    if (this.phase !== 'night') return 0;
    return this.phaseTime / DAY_NIGHT.NIGHT_DURATION;
  }

  getTimeRemaining() {
    switch (this.phase) {
      case 'day': return Math.ceil((DAY_NIGHT.DAY_DURATION - this.phaseTime) / 1000);
      case 'dusk': return Math.ceil((DAY_NIGHT.DUSK_TRANSITION - this.phaseTime) / 1000);
      case 'night': return Math.ceil((DAY_NIGHT.NIGHT_DURATION - this.phaseTime) / 1000);
      case 'dawn': return Math.ceil((DAY_NIGHT.DAWN_TRANSITION - this.phaseTime) / 1000);
      default: return 0;
    }
  }

  getPhaseLabel() {
    switch (this.phase) {
      case 'day': return 'DAY';
      case 'dusk': return 'DUSK';
      case 'night': return 'NIGHT';
      case 'dawn': return 'DAWN';
      default: return '';
    }
  }
}