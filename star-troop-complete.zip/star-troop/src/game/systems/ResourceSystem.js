// ━━━ RESOURCE SYSTEM ━━━
import { WORLD_WIDTH, GROUND_Y, ORE_NODE, SURVIVOR } from '../constants';

export class ResourceSystem {
  scatterOreNodes(entities, centerX) {
    const baseLeft = centerX - 200;
    const baseRight = centerX + 200;

    // Scatter ore across the map, avoiding the base area
    const count = 20;
    for (let i = 0; i < count; i++) {
      let x;
      do {
        x = 200 + Math.random() * (WORLD_WIDTH - 400);
      } while (x > baseLeft && x < baseRight);

      entities.oreNodes.push({
        x,
        y: GROUND_Y - ORE_NODE.HEIGHT / 2 - Math.random() * 4,
        width: ORE_NODE.WIDTH,
        height: ORE_NODE.HEIGHT,
        collected: false,
        glowPhase: Math.random() * Math.PI * 2,
      });
    }
  }

  placeSurvivorPods(entities, centerX) {
    // Place 4 survivor pods at varying distances from base
    const positions = [
      centerX - 600,
      centerX - 1100,
      centerX + 600,
      centerX + 1100,
    ];

    for (const x of positions) {
      if (x > 100 && x < WORLD_WIDTH - 100) {
        entities.survivors.push({
          x,
          y: GROUND_Y - SURVIVOR.HEIGHT / 2,
          width: SURVIVOR.WIDTH,
          height: SURVIVOR.HEIGHT,
          rescued: false,
          pulsePhase: Math.random() * Math.PI * 2,
        });
      }
    }
  }
}