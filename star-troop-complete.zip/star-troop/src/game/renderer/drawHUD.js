// ━━━ HUD RENDERING ━━━
import { CANVAS_WIDTH, CANVAS_HEIGHT, COLORS, PLAYER, BUILDINGS } from '../constants';

export function drawHUD(ctx, engine) {
  const player = engine.entities.player;
  const dn = engine.dayNight;

  // === TOP BAR ===
  ctx.fillStyle = COLORS.UI_BG;
  ctx.fillRect(0, 0, CANVAS_WIDTH, 36);
  ctx.fillStyle = COLORS.UI_BORDER;
  ctx.fillRect(0, 36, CANVAS_WIDTH, 1);

  ctx.font = 'bold 11px monospace';
  ctx.textAlign = 'left';

  // Day/Night indicator
  const phaseLabel = dn.getPhaseLabel();
  const phaseColor = dn.phase === 'night' ? '#cc4444' :
    dn.phase === 'dusk' ? '#cc8844' :
    dn.phase === 'dawn' ? '#ccaa44' : '#88cc88';

  ctx.fillStyle = phaseColor;
  ctx.fillText(`◆ ${phaseLabel}`, 12, 15);

  // Day counter
  ctx.fillStyle = COLORS.UI_TEXT;
  ctx.fillText(`DAY ${dn.dayCount}`, 12, 28);

  // Timer
  const timeLeft = dn.getTimeRemaining();
  ctx.fillStyle = dn.phase === 'night' ? '#cc4444' : COLORS.UI_TEXT;
  ctx.fillText(`${timeLeft}s`, 90, 15);

  // Wave counter
  if (engine.wave > 0) {
    ctx.fillStyle = '#cc6644';
    ctx.fillText(`WAVE ${engine.wave}`, 90, 28);
  }

  // Ore
  ctx.fillStyle = COLORS.ORE;
  ctx.fillText(`ORE: ${engine.ore}`, 180, 15);

  // Score
  ctx.fillStyle = '#ccaa66';
  ctx.fillText(`SCORE ${engine.score}`, 180, 28);

  // Infantry count
  const miCount = engine.entities.infantry.length;
  ctx.fillStyle = '#88aa88';
  ctx.fillText(`TROOPERS: ${miCount}`, 290, 15);

  // Bugs alive
  const bugCount = engine.entities.bugs.filter(b => !b.dead).length;
  if (bugCount > 0) {
    ctx.fillStyle = '#cc4444';
    ctx.fillText(`BUGS: ${bugCount}`, 290, 28);
  }

  // === PLAYER HEALTH BAR (bottom left) ===
  const hpBarX = 12;
  const hpBarY = CANVAS_HEIGHT - 24;
  const hpBarW = 120;
  const hpBarH = 10;
  const hpRatio = player.hp / PLAYER.MAX_HP;

  ctx.fillStyle = COLORS.UI_BG;
  ctx.fillRect(hpBarX - 2, hpBarY - 14, hpBarW + 4, hpBarH + 18);

  ctx.fillStyle = COLORS.UI_TEXT;
  ctx.font = '9px monospace';
  ctx.fillText('HEALTH', hpBarX, hpBarY - 4);

  ctx.fillStyle = '#222';
  ctx.fillRect(hpBarX, hpBarY, hpBarW, hpBarH);

  const hpColor = hpRatio > 0.5 ? COLORS.HEALTH_GREEN : hpRatio > 0.25 ? '#ccaa22' : COLORS.HEALTH_RED;
  ctx.fillStyle = hpColor;
  ctx.fillRect(hpBarX, hpBarY, hpBarW * hpRatio, hpBarH);

  // HP text
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 8px monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${player.hp}/${PLAYER.MAX_HP}`, hpBarX + hpBarW / 2, hpBarY + 8);
  ctx.textAlign = 'left';

  // === GRENADE COOLDOWN (bottom left) ===
  const gcdRatio = Math.max(0, player.grenadeTimer / PLAYER.GRENADE_COOLDOWN);
  ctx.fillStyle = COLORS.UI_TEXT;
  ctx.font = '9px monospace';
  ctx.fillText(`GRENADE [G]`, hpBarX + hpBarW + 12, hpBarY - 4);
  ctx.fillStyle = gcdRatio > 0 ? '#666' : '#88cc44';
  ctx.fillRect(hpBarX + hpBarW + 12, hpBarY, 50, hpBarH);
  if (gcdRatio > 0) {
    ctx.fillStyle = '#88cc44';
    ctx.fillRect(hpBarX + hpBarW + 12, hpBarY, 50 * (1 - gcdRatio), hpBarH);
  }

  // === BUILD HINT (bottom right) ===
  ctx.fillStyle = COLORS.UI_BG;
  ctx.fillRect(CANVAS_WIDTH - 160, CANVAS_HEIGHT - 24, 150, 18);
  ctx.fillStyle = COLORS.UI_TEXT;
  ctx.font = '9px monospace';
  ctx.textAlign = 'right';

  const bs = engine.buildSystem;
  const nextType = bs.buildQueue[bs.buildIndex % bs.buildQueue.length];
  const cost = BUILDINGS[nextType].cost;
  const canAfford = engine.ore >= cost;
  // Flash red if can't afford
  const isFlashing = engine.buildFailFlash > 0 && Math.floor(engine.buildFailFlash / 120) % 2 === 0;
  ctx.fillStyle = (!canAfford && isFlashing) ? '#ff2222' : (canAfford ? '#88cc44' : '#cc4444');
  ctx.fillText(`[B] Build ${BUILDINGS[nextType].label} (${cost} ore)`, CANVAS_WIDTH - 16, CANVAS_HEIGHT - 12);
  ctx.textAlign = 'left';

  // === CONTROLS HINT (first 15 seconds) ===
  if (engine.dayNight.dayCount === 1 && engine.dayNight.phase === 'day' && engine.dayNight.phaseTime < 15000) {
    const alpha = Math.min(1, 1 - (engine.dayNight.phaseTime - 12000) / 3000);
    if (alpha > 0) {
      ctx.globalAlpha = Math.max(0, alpha);
      ctx.fillStyle = COLORS.UI_BG;
      ctx.fillRect(CANVAS_WIDTH / 2 - 140, CANVAS_HEIGHT - 70, 280, 50);
      ctx.fillStyle = COLORS.UI_TEXT;
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('A/D: Move  W/Space: Jump  Click: Shoot', CANVAS_WIDTH / 2, CANVAS_HEIGHT - 52);
      ctx.fillText('G: Grenade  B: Build  Collect ore & rescue survivors!', CANVAS_WIDTH / 2, CANVAS_HEIGHT - 38);
      ctx.textAlign = 'left';
      ctx.globalAlpha = 1;
    }
  }

  // === NIGHT WARNING ===
  if (dn.phase === 'day' && dn.getTimeRemaining() <= 10) {
    const pulse = Math.sin(Date.now() * 0.008) * 0.4 + 0.6;
    ctx.globalAlpha = pulse;
    ctx.fillStyle = '#cc4444';
    ctx.font = 'bold 16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('⚠ NIGHT APPROACHES ⚠', CANVAS_WIDTH / 2, 60);
    ctx.textAlign = 'left';
    ctx.globalAlpha = 1;
  }

  // === DAWN MESSAGE ===
  if (dn.phase === 'dawn' && dn.phaseTime < 3000) {
    const alpha = Math.min(1, dn.phaseTime / 500) * Math.max(0, 1 - (dn.phaseTime - 2000) / 1000);
    if (alpha > 0) {
      ctx.globalAlpha = Math.max(0, alpha);
      ctx.fillStyle = '#ccaa44';
      ctx.font = 'bold 20px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('★ DAWN — YOU SURVIVED ★', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 40);
      ctx.textAlign = 'left';
      ctx.globalAlpha = 1;
    }
  }

  // === BUG DIRECTION ARROWS (when bugs off-screen) ===
  const liveBugs = engine.entities.bugs.filter(b => !b.dead);
  if (liveBugs.length > 0) {
    const player = engine.entities.player;
    const leftBugs  = liveBugs.filter(b => b.x < player.x - 480);
    const rightBugs = liveBugs.filter(b => b.x > player.x + 480);

    const arrowY = CANVAS_HEIGHT / 2;
    const pulse  = 0.6 + Math.sin(Date.now() * 0.006) * 0.4;

    if (leftBugs.length > 0) {
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.fillStyle = '#cc3333';
      ctx.beginPath();
      ctx.moveTo(18, arrowY);
      ctx.lineTo(30, arrowY - 8);
      ctx.lineTo(30, arrowY + 8);
      ctx.closePath();
      ctx.fill();
      ctx.font = 'bold 8px monospace';
      ctx.fillStyle = '#ff6666';
      ctx.textAlign = 'left';
      ctx.fillText(`×${leftBugs.length}`, 32, arrowY + 3);
      ctx.restore();
    }
    if (rightBugs.length > 0) {
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.fillStyle = '#cc3333';
      ctx.beginPath();
      ctx.moveTo(CANVAS_WIDTH - 18, arrowY);
      ctx.lineTo(CANVAS_WIDTH - 30, arrowY - 8);
      ctx.lineTo(CANVAS_WIDTH - 30, arrowY + 8);
      ctx.closePath();
      ctx.fill();
      ctx.font = 'bold 8px monospace';
      ctx.fillStyle = '#ff6666';
      ctx.textAlign = 'right';
      ctx.fillText(`×${rightBugs.length}`, CANVAS_WIDTH - 32, arrowY + 3);
      ctx.restore();
    }
  }

}