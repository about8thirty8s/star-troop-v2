// ━━━ PLAYER SPRITE ━━━
import { COLORS } from '../../constants';

export function drawPlayer(ctx, player, cam, dn) {
  const sx = cam.worldToScreen(player.x);
  const sy = player.y;
  const f  = player.facing;
  const w  = player.width;
  const h  = player.height;

  // Invulnerability flash
  if (player.invulnTimer > 0 && Math.floor(player.invulnTimer / 60) % 2) return;

  ctx.save();
  ctx.translate(sx, sy);

  // Walk bob
  const bob = player.walkFrame % 2 === 1 ? -1 : 0;

  // === LEGS ===
  const legSpread = player.walkFrame % 2 === 0 ? 3 : -3;
  ctx.fillStyle = '#3a4a2a';
  ctx.fillRect(-5 + legSpread * f, -6, 4, 8);
  ctx.fillRect(1  - legSpread * f, -6, 4, 8);
  // Boots
  ctx.fillStyle = '#2a2a1a';
  ctx.fillRect(-6 + legSpread * f, 0, 6, 3);
  ctx.fillRect(0  - legSpread * f, 0, 6, 3);

  // === TORSO ===
  ctx.fillStyle = COLORS.PLAYER;
  ctx.fillRect(-7, -22 + bob, 14, 16);
  // Armour plate
  ctx.fillStyle = '#4a5a3a';
  ctx.fillRect(-5, -20 + bob, 10, 8);
  // Belt
  ctx.fillStyle = '#3a3020';
  ctx.fillRect(-7, -8 + bob, 14, 2);

  // === HEAD ===
  ctx.fillStyle = '#4a5a3a';
  ctx.fillRect(-6, -32 + bob, 12, 10);
  // Visor
  ctx.fillStyle = '#8ab';
  ctx.fillRect(f > 0 ? -1 : -5, -29 + bob, 6, 3);

  // === ARMS + GUN — rotated to aimAngle ===
  const armOriginY = -16 + bob; // shoulder height

  // Back arm (non-gun side) — static
  ctx.fillStyle = COLORS.PLAYER;
  ctx.fillRect(-3 * f - 2, armOriginY, 4, 10);

  // Gun arm — rotated to aim angle
  // Clamp aim angle to reasonable range (don't let gun point fully behind player)
  let aim = player.aimAngle || 0;
  // Mirror angle when facing left so the gun still points at cursor
  const displayAngle = f < 0 ? Math.PI - aim : aim;
  // Clamp vertical: don't let gun point more than 55° up or 40° down
  const clampedAngle = Math.max(-Math.PI * 0.55, Math.min(Math.PI * 0.40, displayAngle));

  ctx.save();
  ctx.translate(f * 4, armOriginY + 4); // pivot at shoulder
  ctx.rotate(clampedAngle);

  // Arm
  ctx.fillStyle = COLORS.PLAYER;
  ctx.fillRect(-2, 0, 4, 10);

  // Morita Rifle (drawn along positive X from pivot)
  ctx.fillStyle = '#2a2a2a';
  ctx.fillRect(2, -2, 16, 4);     // main body
  ctx.fillStyle = '#444';
  ctx.fillRect(2, -3, 10, 2);     // top rail
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(14, -1, 5, 2);     // barrel extension

  // Muzzle flash — at tip of barrel (18px from pivot)
  if (player.muzzleFlash > 0) {
    const flashAlpha = player.muzzleFlash / 60;
    const flashSize  = 4 + player.muzzleFlash * 0.08;
    ctx.globalAlpha = flashAlpha;
    // Outer glow
    ctx.fillStyle = COLORS.MUZZLE_FLASH;
    ctx.beginPath();
    ctx.arc(20, 0, flashSize, 0, Math.PI * 2);
    ctx.fill();
    // Core white
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(20, 0, flashSize * 0.45, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  ctx.restore(); // gun arm transform

  ctx.restore(); // player transform
}
