// ━━━ BUILDING SPRITES ━━━
import { COLORS, GROUND_Y } from '../../constants';

export function drawBuilding(ctx, building, cam) {
  const sx = cam.worldToScreen(building.x);
  const sy = building.y;
  const w = building.width;
  const h = building.height;

  if (building.destroyed) {
    // Rubble
    ctx.fillStyle = '#3a3a2a';
    ctx.fillRect(sx, GROUND_Y - 8, w, 8);
    ctx.fillStyle = '#4a4a3a';
    ctx.fillRect(sx + 4, GROUND_Y - 12, w - 8, 6);
    return;
  }

  // Health bar
  const hpRatio = building.hp / building.maxHp;
  if (hpRatio < 1) {
    ctx.fillStyle = '#333';
    ctx.fillRect(sx, sy - 6, w, 3);
    ctx.fillStyle = hpRatio > 0.5 ? COLORS.HEALTH_GREEN : COLORS.HEALTH_RED;
    ctx.fillRect(sx, sy - 6, w * hpRatio, 3);
  }

  switch (building.type) {
    case 'COMMAND_POST':
      _drawHQ(ctx, sx, sy, w, h);
      break;
    case 'BARRACKS':
      _drawBarracks(ctx, sx, sy, w, h);
      break;
    case 'WALL':
      _drawWall(ctx, sx, sy, w, h);
      break;
    case 'GUARD_TOWER':
      _drawTower(ctx, sx, sy, w, h);
      break;
  }
}

function _drawHQ(ctx, sx, sy, w, h) {
  // Main structure
  ctx.fillStyle = COLORS.HQ;
  ctx.fillRect(sx + 4, sy + 10, w - 8, h - 10);

  // Roof
  ctx.fillStyle = '#4a5a4a';
  ctx.beginPath();
  ctx.moveTo(sx, sy + 12);
  ctx.lineTo(sx + w / 2, sy);
  ctx.lineTo(sx + w, sy + 12);
  ctx.fill();

  // Door
  ctx.fillStyle = '#2a3a2a';
  ctx.fillRect(sx + w / 2 - 6, sy + h - 18, 12, 18);

  // Windows
  ctx.fillStyle = '#8ab';
  ctx.fillRect(sx + 8, sy + 18, 8, 6);
  ctx.fillRect(sx + w - 16, sy + 18, 8, 6);

  // Federation emblem (simple star)
  ctx.fillStyle = '#cc8844';
  ctx.fillRect(sx + w / 2 - 3, sy + 4, 6, 6);

  // Label
  ctx.fillStyle = COLORS.UI_TEXT;
  ctx.font = '8px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('HQ', sx + w / 2, sy + h + 10);
}

function _drawBarracks(ctx, sx, sy, w, h) {
  ctx.fillStyle = COLORS.BUILDING;
  ctx.fillRect(sx + 2, sy + 6, w - 4, h - 6);

  // Roof
  ctx.fillStyle = COLORS.BUILDING_ACCENT;
  ctx.fillRect(sx, sy, w, 8);

  // Door
  ctx.fillStyle = '#3a3a2a';
  ctx.fillRect(sx + w / 2 - 5, sy + h - 14, 10, 14);

  // Window
  ctx.fillStyle = '#8ab';
  ctx.fillRect(sx + 6, sy + 14, 6, 5);
  ctx.fillRect(sx + w - 14, sy + 14, 6, 5);
}

function _drawWall(ctx, sx, sy, w, h) {
  // Main wall
  ctx.fillStyle = COLORS.WALL;
  ctx.fillRect(sx, sy, w, h);

  // Stone texture
  ctx.fillStyle = '#6a6a5a';
  for (let y = 0; y < h; y += 8) {
    const off = (y / 8) % 2 === 0 ? 0 : 4;
    ctx.fillRect(sx + off, sy + y, w / 2 - 1, 7);
    ctx.fillRect(sx + off + w / 2, sy + y, w / 2 - off, 7);
  }

  // Top
  ctx.fillStyle = '#8a8a7a';
  ctx.fillRect(sx - 2, sy - 2, w + 4, 4);

  // Battlement notches
  ctx.fillStyle = COLORS.WALL;
  ctx.fillRect(sx + 2, sy - 6, 4, 6);
  ctx.fillRect(sx + w - 6, sy - 6, 4, 6);
}

function _drawTower(ctx, sx, sy, w, h) {
  // Tower body
  ctx.fillStyle = COLORS.BUILDING;
  ctx.fillRect(sx + 4, sy + 12, w - 8, h - 12);

  // Platform
  ctx.fillStyle = COLORS.BUILDING_ACCENT;
  ctx.fillRect(sx - 2, sy + 8, w + 4, 6);

  // Roof
  ctx.fillStyle = '#5a5a4a';
  ctx.beginPath();
  ctx.moveTo(sx + 2, sy + 10);
  ctx.lineTo(sx + w / 2, sy);
  ctx.lineTo(sx + w - 2, sy + 10);
  ctx.fill();

  // Spotlight mount
  ctx.fillStyle = '#aaa';
  ctx.fillRect(sx + w / 2 - 3, sy + 10, 6, 4);
}