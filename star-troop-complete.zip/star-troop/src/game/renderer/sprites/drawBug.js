// ━━━ WARRIOR BUG SPRITE ━━━
import { COLORS } from '../../constants';

export function drawBug(ctx, bug, cam) {
  const sx = cam.worldToScreen(bug.x);
  const sy = bug.y;
  const f = bug.facing;

  if (bug.dead) {
    // Dead bug: flattened, fading
    const alpha = Math.max(0, 1 - bug.deathTimer / 1500);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = COLORS.BUG_BODY;
    ctx.fillRect(sx - 14, sy - 4, 28, 6);
    ctx.fillStyle = COLORS.BUG_BLOOD;
    ctx.fillRect(sx - 8, sy - 2, 16, 4);
    ctx.globalAlpha = 1;
    return;
  }

  ctx.save();
  ctx.translate(sx, sy);

  // Hit flash
  if (bug.hitFlash > 0) {
    ctx.fillStyle = '#ffffff';
  }

  // === LEGS ===
  const legAnim = bug.legFrame;
  ctx.fillStyle = bug.hitFlash > 0 ? '#fff' : COLORS.BUG_ACCENT;

  // 3 pairs of legs
  for (let i = 0; i < 3; i++) {
    const offset = (legAnim + i) % 4;
    const yOff = offset < 2 ? -2 : 2;
    const legX = -10 + i * 10;
    // Left leg
    ctx.fillRect(legX - 4, -6 + yOff, 3, 8);
    // Right leg
    ctx.fillRect(legX + 2, -6 - yOff, 3, 8);
  }

  // === BODY ===
  ctx.fillStyle = bug.hitFlash > 0 ? '#fff' : COLORS.BUG_BODY;

  // Abdomen (back)
  ctx.beginPath();
  ctx.ellipse(-f * 6, -10, 12, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Thorax (front)
  ctx.fillStyle = bug.hitFlash > 0 ? '#fff' : COLORS.BUG_ACCENT;
  ctx.beginPath();
  ctx.ellipse(f * 4, -12, 8, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // === HEAD ===
  ctx.fillStyle = bug.hitFlash > 0 ? '#fff' : '#1a0a00';
  ctx.beginPath();
  ctx.ellipse(f * 14, -14, 6, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Mandibles
  ctx.fillStyle = bug.hitFlash > 0 ? '#fff' : '#4a2a0a';
  ctx.fillRect(f * 18, -16, f * 5, 2);
  ctx.fillRect(f * 18, -12, f * 5, 2);

  // Eyes (red dots)
  if (bug.hitFlash <= 0) {
    ctx.fillStyle = '#cc2200';
    ctx.fillRect(f * 16, -16, 2, 2);
    ctx.fillRect(f * 16, -12, 2, 2);
  }

  // Carapace highlight
  if (bug.hitFlash <= 0) {
    ctx.fillStyle = 'rgba(100, 60, 20, 0.3)';
    ctx.beginPath();
    ctx.ellipse(-f * 4, -14, 6, 3, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}