// ━━━ MOBILE INFANTRY SPRITE ━━━
import { COLORS } from '../../constants';

export function drawInfantry(ctx, mi, cam) {
  const sx = cam.worldToScreen(mi.x);
  const sy = mi.y;
  const f = mi.facing;

  ctx.save();
  ctx.translate(sx, sy);

  const bob = mi.walkFrame % 2 === 1 ? -1 : 0;
  const legSpread = mi.walkFrame % 2 === 0 ? 2 : -2;

  // Health bar
  const hpRatio = mi.hp / mi.maxHp;
  if (hpRatio < 1) {
    ctx.fillStyle = '#333';
    ctx.fillRect(-8, -mi.height - 4, 16, 2);
    ctx.fillStyle = hpRatio > 0.5 ? COLORS.HEALTH_GREEN : COLORS.HEALTH_RED;
    ctx.fillRect(-8, -mi.height - 4, 16 * hpRatio, 2);
  }

  // Legs
  ctx.fillStyle = '#3a4a2a';
  ctx.fillRect(-4 + legSpread * f, -5, 3, 7);
  ctx.fillRect(1 - legSpread * f, -5, 3, 7);

  // Boots
  ctx.fillStyle = '#2a2a1a';
  ctx.fillRect(-5 + legSpread * f, 0, 5, 2);
  ctx.fillRect(0 - legSpread * f, 0, 5, 2);

  // Torso
  ctx.fillStyle = COLORS.MI_UNIFORM;
  ctx.fillRect(-6, -19 + bob, 12, 14);

  // Armor vest
  ctx.fillStyle = '#3a5a2a';
  ctx.fillRect(-4, -17 + bob, 8, 6);

  // Head
  ctx.fillStyle = '#3a4a2a';
  ctx.fillRect(-5, -27 + bob, 10, 8);

  // Face
  ctx.fillStyle = COLORS.PLAYER_SKIN;
  ctx.fillRect(f > 0 ? 0 : -4, -24 + bob, 4, 4);

  // Gun
  ctx.fillStyle = '#333';
  ctx.fillRect(f * 4, -15 + bob, f * 10, 2);

  // Muzzle flash
  if (mi.muzzleFlash > 0) {
    const flashSize = 3 + mi.muzzleFlash * 0.08;
    ctx.fillStyle = COLORS.MUZZLE_FLASH;
    ctx.globalAlpha = mi.muzzleFlash / 50;
    ctx.beginPath();
    ctx.arc(f * 15, -14 + bob, flashSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // HP bar (only show when damaged)
  if (mi.hp < mi.maxHp && mi.hp > 0) {
    const barW = 20;
    const barH = 3;
    const barX = sx - barW / 2;
    const barY = sy - mi.height - 6;
    const hpR  = mi.hp / mi.maxHp;
    ctx.fillStyle = '#222';
    ctx.fillRect(barX, barY, barW, barH);
    ctx.fillStyle = hpR > 0.5 ? '#44cc44' : hpR > 0.25 ? '#ccaa22' : '#cc2222';
    ctx.fillRect(barX, barY, barW * hpR, barH);
  }

  ctx.restore();
}