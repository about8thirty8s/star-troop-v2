// ━━━ WARRIOR BUG ENTITY ━━━
import { WARRIOR_BUG, GROUND_Y, GRAVITY } from '../constants';

export class WarriorBug {
  constructor(x) {
    this.x = x;
    this.y = GROUND_Y;
    this.vx = 0;
    this.vy = 0;
    this.width = WARRIOR_BUG.WIDTH;
    this.height = WARRIOR_BUG.HEIGHT;
    this.hp = WARRIOR_BUG.MAX_HP;
    this.maxHp = WARRIOR_BUG.MAX_HP;
    this.speed = WARRIOR_BUG.SPEED + Math.random() * 0.4;
    this.damage = WARRIOR_BUG.DAMAGE;
    this.attackTimer = 0;
    this.facing = 1;
    this.dead = false;
    this.deathTimer = 0;
    this.target = null;
    this.legFrame = 0;
    this.legTimer = 0;
    this.hitFlash = 0;
  }

  update(dt, engine) {
    if (this.dead) {
      this.deathTimer += dt;
      return;
    }

    // Gravity
    this.vy += GRAVITY * 0.5;
    this.x += this.vx;
    this.y += this.vy;

    if (this.y >= GROUND_Y) {
      this.y = GROUND_Y;
      this.vy = 0;
    }

    // Leg animation
    if (Math.abs(this.vx) > 0.1) {
      this.legTimer += dt;
      if (this.legTimer > 100) {
        this.legTimer = 0;
        this.legFrame = (this.legFrame + 1) % 4;
      }
    }

    if (this.attackTimer > 0) this.attackTimer -= dt;
    if (this.hitFlash > 0) this.hitFlash -= dt;
  }

  takeDamage(amount, engine) {
    this.hp -= amount;
    this.hitFlash = 80;

    if (this.hp <= 0 && !this.dead) {
      this.dead = true;
      this.deathTimer = 0;
      this.vx = 0;
      engine.score += WARRIOR_BUG.SCORE;

      // Bug death FX — green blood
      engine.fx.spawnBugDeath(this.x, this.y, engine.entities.particles);
      engine.fx.addShake(2);
    }
  }
}