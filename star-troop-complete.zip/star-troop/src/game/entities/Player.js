// ━━━ PLAYER ENTITY ━━━
import { PLAYER, GROUND_Y, GRAVITY, WORLD_WIDTH, COLORS, ORE_NODE, SURVIVOR } from '../constants';
import { MobileInfantry } from './MobileInfantry';

// Sustained fire shake config — build up the longer you hold the trigger
const SHAKE_BASE        = 1.2;   // shake per shot at zero sustain
const SHAKE_MAX         = 7.0;   // shake per shot at full sustain
const SUSTAIN_RAMP_MS   = 2400;  // ms to reach full shake intensity
const SUSTAIN_DECAY_MS  = 600;   // ms to fully cool down after releasing trigger

export class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.width  = PLAYER.WIDTH;
    this.height = PLAYER.HEIGHT;
    this.hp     = PLAYER.MAX_HP;
    this.facing = 1;       // 1 = right, -1 = left  (kept for formation/sprite logic)
    this.grounded   = false;
    this.fireTimer  = 0;
    this.grenadeTimer = 0;
    this.isFiring   = false;
    this.muzzleFlash = 0;
    this.walkFrame  = 0;
    this.walkTimer  = 0;
    this.invulnTimer = 0;
    // Aiming
    this.aimAngle   = 0;   // radians — world-space angle from player to cursor
    // Sustained fire
    this.sustainedFireMs = 0;   // ms of continuous fire
  }

  handleInput(keys, mouseDown, dt, engine) {
    // ── Movement ────────────────────────────────────────────────────────────
    let moveX = 0;
    if (keys['KeyA'] || keys['ArrowLeft'])  moveX -= 1;
    if (keys['KeyD'] || keys['ArrowRight']) moveX += 1;

    this.vx = moveX * PLAYER.SPEED;
    if (moveX !== 0) this.facing = moveX;

    // Walk animation
    if (moveX !== 0) {
      this.walkTimer += dt;
      if (this.walkTimer > 150) {
        this.walkTimer = 0;
        this.walkFrame = (this.walkFrame + 1) % 4;
      }
    } else {
      this.walkFrame = 0;
      this.walkTimer = 0;
    }

    // ── Jump ────────────────────────────────────────────────────────────────
    if ((keys['KeyW'] || keys['ArrowUp'] || keys['Space']) && this.grounded) {
      this.vy = PLAYER.JUMP_FORCE;
      this.grounded = false;
    }

    // ── Aim — world-space angle to cursor ───────────────────────────────────
    // Muzzle position (centre of player, chest height)
    const muzzleX = this.x;
    const muzzleY = this.y - this.height * 0.55;
    // engine.getWorldMouseX() gives world X; mouseY is already screen Y (Y is flat world)
    const worldMouseX = engine.getWorldMouseX();
    const worldMouseY = engine.mouseY;
    const dx = worldMouseX - muzzleX;
    const dy = worldMouseY - muzzleY;
    this.aimAngle = Math.atan2(dy, dx);
    // Keep facing in sync with aim direction for sprite flip
    if (dx !== 0) this.facing = dx > 0 ? 1 : -1;

    // ── Fire ────────────────────────────────────────────────────────────────
    this.isFiring = mouseDown;
    if (mouseDown) {
      this.sustainedFireMs = Math.min(this.sustainedFireMs + dt, SUSTAIN_RAMP_MS);
      this.fireTimer -= dt;
      if (this.fireTimer <= 0) {
        this._fire(engine);
        this.fireTimer = PLAYER.FIRE_RATE;
      }
    } else {
      // Cool down faster than ramp-up — responsive, not punishing
      this.sustainedFireMs = Math.max(0, this.sustainedFireMs - dt * (SUSTAIN_RAMP_MS / SUSTAIN_DECAY_MS));
      this.fireTimer = 0;
    }

    // ── Grenade ─────────────────────────────────────────────────────────────
    if (keys['KeyG'] || keys['KeyE']) {
      if (this.grenadeTimer <= 0) {
        this._throwGrenade(engine);
        this.grenadeTimer = PLAYER.GRENADE_COOLDOWN;
      }
      keys['KeyG'] = false;
      keys['KeyE'] = false;
    }

    // ── Build ────────────────────────────────────────────────────────────────
    if (keys['KeyB']) {
      keys['KeyB'] = false;
      engine.buildSystem.tryBuild(engine);
    }

    // ── Pickups ──────────────────────────────────────────────────────────────
    this._checkOrePickup(engine);
    this._checkSurvivorRescue(engine);
  }

  update(dt, engine) {
    this.vy += GRAVITY;
    this.x  += this.vx;
    this.y  += this.vy;

    if (this.y >= GROUND_Y) {
      this.y = GROUND_Y;
      this.vy = 0;
      this.grounded = true;
    }

    this.x = Math.max(this.width, Math.min(WORLD_WIDTH - this.width, this.x));

    if (this.grenadeTimer > 0) this.grenadeTimer -= dt;
    if (this.muzzleFlash   > 0) this.muzzleFlash -= dt;
    if (this.invulnTimer   > 0) this.invulnTimer -= dt;
  }

  takeDamage(amount, engine) {
    if (this.invulnTimer > 0) return;
    this.hp -= amount;
    this.invulnTimer = 300;
    engine.fx.addShake(4);
    engine.fx.spawnHitFX(this.x, this.y - this.height / 2, '#cc4444', engine.entities.particles);
    if (this.hp <= 0) {
      this.hp = 0;
      engine.triggerGameOver('player_dead');
    }
  }

  _fire(engine) {
    // ── Sustained fire shake — escalates the longer you hold the trigger ──
    const sustainRatio  = this.sustainedFireMs / SUSTAIN_RAMP_MS;  // 0..1
    const shakeStrength = SHAKE_BASE + (SHAKE_MAX - SHAKE_BASE) * sustainRatio;
    engine.fx.addShake(shakeStrength);

    // ── Bullet direction from aim angle ──
    const speed = PLAYER.BULLET_SPEED;
    // Small spread that also grows with sustained fire (heat)
    const spread = 0.04 + sustainRatio * 0.10;
    const angle  = this.aimAngle + (Math.random() - 0.5) * spread;
    const vx     = Math.cos(angle) * speed;
    const vy     = Math.sin(angle) * speed;

    // Muzzle position
    const muzzleX = this.x + Math.cos(this.aimAngle) * 14;
    const muzzleY = (this.y - this.height * 0.55) + Math.sin(this.aimAngle) * 14;

    engine.entities.projectiles.push({
      x: muzzleX,
      y: muzzleY,
      vx, vy,
      damage: PLAYER.BULLET_DAMAGE,
      friendly: true,
      life: 900,
      trail: [],
    });

    this.muzzleFlash = 60;

    // Muzzle flash particles — burst in aim direction
    for (let i = 0; i < 4; i++) {
      const a = this.aimAngle + (Math.random() - 0.5) * 0.6;
      engine.entities.particles.push({
        x: muzzleX,
        y: muzzleY,
        vx: Math.cos(a) * (3 + Math.random() * 5),
        vy: Math.sin(a) * (3 + Math.random() * 5),
        life: 70 + Math.random() * 50,
        maxLife: 120,
        color: COLORS.MUZZLE_FLASH,
        size: 2 + Math.random() * 2,
      });
    }

    // Shell casing eject (opposite of aim direction, upward)
    engine.entities.particles.push({
      x: this.x,
      y: this.y - this.height * 0.55,
      vx: -this.facing * (1.5 + Math.random() * 2),
      vy: -(1.5 + Math.random() * 2.5),
      life: 400 + Math.random() * 200,
      maxLife: 600,
      color: '#cc9922',
      size: 1.5,
    });
  }

  _throwGrenade(engine) {
    const vx = Math.cos(this.aimAngle) * 6;
    // Clamp vy so grenade never fires straight into the ground
    const vy = Math.min(2, Math.sin(this.aimAngle) * 6 - 2);
    engine.entities.grenades.push({
      x: this.x,
      y: this.y - this.height / 2,
      vx, vy,
      life: 1200,
      damage: PLAYER.GRENADE_DAMAGE,
      radius: PLAYER.GRENADE_RADIUS,
    });
  }

  _checkOrePickup(engine) {
    for (let i = engine.entities.oreNodes.length - 1; i >= 0; i--) {
      const ore = engine.entities.oreNodes[i];
      if (ore.collected) continue;
      const dx = this.x - ore.x;
      const dy = (this.y - this.height / 2) - ore.y;
      if (Math.abs(dx) < ORE_NODE.PICKUP_RANGE && Math.abs(dy) < ORE_NODE.PICKUP_RANGE) {
        ore.collected = true;
        engine.ore += ORE_NODE.YIELD;
        engine.fx.spawnPickupFX(ore.x, ore.y, COLORS.ORE, engine.entities.particles);
        engine.entities.particles.push({
          x: ore.x, y: ore.y - 10,
          vx: 0, vy: -0.8,
          life: 800, maxLife: 800,
          text: `+${ORE_NODE.YIELD}`,
          color: COLORS.ORE, size: 10,
        });
      }
    }
  }

  _checkSurvivorRescue(engine) {
    for (let i = engine.entities.survivors.length - 1; i >= 0; i--) {
      const s = engine.entities.survivors[i];
      if (s.rescued) continue;
      const dx = this.x - s.x;
      const dy = (this.y - this.height / 2) - s.y;
      if (Math.abs(dx) < SURVIVOR.RESCUE_RANGE && Math.abs(dy) < SURVIVOR.RESCUE_RANGE) {
        s.rescued = true;
        const mi = new MobileInfantry(s.x, GROUND_Y);
        engine.entities.infantry.push(mi);
        engine.fx.spawnPickupFX(s.x, s.y, '#44aaff', engine.entities.particles);
        engine.entities.particles.push({
          x: s.x, y: s.y - 10,
          vx: 0, vy: -0.8,
          life: 1000, maxLife: 1000,
          text: 'RESCUED!',
          color: '#44aaff', size: 10,
        });
      }
    }
  }
}
