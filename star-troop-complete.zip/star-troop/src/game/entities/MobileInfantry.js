// ━━━ MOBILE INFANTRY ENTITY ━━━
import { MI, GROUND_Y, GRAVITY, COLORS } from '../constants';

export class MobileInfantry {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.width = MI.WIDTH;
    this.height = MI.HEIGHT;
    this.hp = MI.MAX_HP;
    this.maxHp = MI.MAX_HP;
    this.speed = MI.SPEED;
    this.facing = 1;
    this.fireTimer = 0;
    this.muzzleFlash = 0;
    this.walkFrame = 0;
    this.walkTimer = 0;
    this.holdX     = null;
    this.defenseX  = null;
    this.defenseY  = null;
    this.state     = 'follow'; // follow | hold | waiting | engage
    this.target    = null;
    this.role      = 'infantry'; // infantry | scientist | miner | medic | pilot
    this.podId     = null;       // set while waiting at a lifepod
    // Idle state (managed by SquadIdle)
    this.idleState       = 'idle_alert';
    this.idleTimer       = 3000 + Math.random() * 3000;
    this.idleVariant     = 'check_rifle';
    this.playerStopTimer = 0;
    // Formation (managed by SquadFormation)
    this.slotIndex   = undefined;
    this.idlePhase   = Math.random() * Math.PI * 2;
    this.idleSpeedX  = 0.38 + Math.random() * 0.28;
    this.idleSpeedY  = 0.22 + Math.random() * 0.18;
    this.idleAmpX    = 1.4 + Math.random() * 1.4;
    this.idleAmpY    = 0.8 + Math.random() * 0.8;
    this.lerpSpeed   = 0.07 + (Math.random() - 0.5) * 0.03;
  }

  update(dt, engine) {
    if (this.state === 'waiting') return; // at pod — no AI until rescued
    this.vy += GRAVITY;
    this.x += this.vx;
    this.y += this.vy;

    if (this.y >= GROUND_Y) {
      this.y = GROUND_Y;
      this.vy = 0;
    }

    // Walk animation
    if (Math.abs(this.vx) > 0.2) {
      this.walkTimer += dt;
      if (this.walkTimer > 160) {
        this.walkTimer = 0;
        this.walkFrame = (this.walkFrame + 1) % 4;
      }
    } else {
      this.walkFrame = 0;
    }

    if (this.fireTimer > 0) this.fireTimer -= dt;
    if (this.muzzleFlash > 0) this.muzzleFlash -= dt;
  }

  fire(targetX, engine) {
    if (this.fireTimer > 0) return;
    this.fireTimer = MI.FIRE_RATE;

    const dir = targetX > this.x ? 1 : -1;
    this.facing = dir;

    const bx = this.x + dir * 12;
    const by = this.y - this.height / 2 - 2;

    engine.entities.projectiles.push({
      x: bx,
      y: by,
      vx: MI.BULLET_SPEED * dir,
      vy: (Math.random() - 0.5) * 0.8,
      damage: MI.BULLET_DAMAGE,
      friendly: true,
      life: 280,
      trail: [],
    });

    this.muzzleFlash = 50;

    // Small flash particles
    for (let i = 0; i < 2; i++) {
      engine.entities.particles.push({
        x: bx,
        y: by,
        vx: dir * (2 + Math.random() * 3),
        vy: (Math.random() - 0.5) * 1.5,
        life: 60 + Math.random() * 40,
        maxLife: 100,
        color: COLORS.MUZZLE_FLASH,
        size: 1.5 + Math.random() * 1.5,
      });
    }
  }

  takeDamage(amount, engine) {
    this.hp -= amount;
    engine.fx.spawnHitFX(this.x, this.y - this.height / 2, '#cc4444', engine.entities.particles);
  }
}