import React, { useRef, useEffect, useState, useCallback } from 'react';
import { GameEngine } from '../game/GameEngine';

export default function StarTroop() {
  const canvasRef  = useRef(null);
  const engineRef  = useRef(null);
  const [started, setStarted] = useState(false);

  const startGame = useCallback(() => {
    if (engineRef.current) engineRef.current.destroy();
    const engine = new GameEngine(canvasRef.current);
    engine.init();
    engine.start();
    engineRef.current = engine;
    setStarted(true);
    // Give canvas focus immediately so keyboard works
    setTimeout(() => canvasRef.current?.focus(), 50);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Listen for restart event fired by the engine (R key on game-over/win)
    const onRestart = () => startGame();
    canvas.addEventListener('st:restart', onRestart);

    // Suppress context menu at the React layer too (belt-and-suspenders)
    const onCtxMenu = (e) => e.preventDefault();
    canvas.addEventListener('contextmenu', onCtxMenu);

    return () => {
      canvas.removeEventListener('st:restart', onRestart);
      canvas.removeEventListener('contextmenu', onCtxMenu);
      if (engineRef.current) engineRef.current.destroy();
    };
  }, [startGame]);

  return (
    <div
      className="min-h-screen bg-background flex flex-col items-center justify-center p-2 select-none"
      // Prevent right-click context menu anywhere on the game page
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="relative w-full max-w-[960px]">
        {!started && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-background/95 rounded-lg">
            <h1
              className="text-4xl font-bold tracking-wider text-primary mb-2"
              style={{ fontFamily: 'monospace', letterSpacing: '0.15em' }}
            >
              STAR TROOP
            </h1>
            <p className="text-muted-foreground text-sm mb-1" style={{ fontFamily: 'monospace' }}>
              Survive the bug onslaught. Defend the base.
            </p>

            {/* Controls reference — visible before game starts */}
            <div className="mb-5 mt-2 text-center" style={{ fontFamily: 'monospace' }}>
              <p className="text-muted-foreground text-xs opacity-70 mb-1">
                A / D &nbsp;·&nbsp; Move &nbsp;&nbsp;&nbsp; W / Space &nbsp;·&nbsp; Jump
              </p>
              <p className="text-muted-foreground text-xs opacity-70 mb-1">
                Mouse &nbsp;·&nbsp; Aim &amp; Shoot &nbsp;&nbsp;&nbsp; G &nbsp;·&nbsp; Grenade &nbsp;&nbsp;&nbsp; B &nbsp;·&nbsp; Build
              </p>
              <p className="text-muted-foreground text-xs opacity-50">
                ESC &nbsp;·&nbsp; Pause &nbsp;&nbsp;&nbsp; R &nbsp;·&nbsp; Restart
              </p>
            </div>

            <button
              onClick={startGame}
              className="px-8 py-3 bg-primary text-primary-foreground font-bold text-lg rounded tracking-widest hover:opacity-90 transition-opacity"
              style={{ fontFamily: 'monospace' }}
            >
              DEPLOY
            </button>
          </div>
        )}

        <canvas
          ref={canvasRef}
          // tabIndex makes canvas focusable for keyboard events
          tabIndex={0}
          className="w-full rounded-lg border border-border outline-none"
          style={{
            imageRendering: 'pixelated',
            aspectRatio: '960 / 540',
            cursor: started ? 'none' : 'default',  // hide OS cursor — we draw our own crosshair
          }}
          // Click canvas → grab focus (keyboard works again)
          onClick={() => canvasRef.current?.focus()}
          onContextMenu={(e) => e.preventDefault()}
        />
      </div>

      <div className="mt-3 text-center">
        <p className="text-muted-foreground text-xs" style={{ fontFamily: 'monospace' }}>
          {started
            ? 'ESC — pause / controls   ·   R — restart after game over'
            : 'STARTROOP MVP — Explore by day, survive by night'}
        </p>
      </div>
    </div>
  );
}
